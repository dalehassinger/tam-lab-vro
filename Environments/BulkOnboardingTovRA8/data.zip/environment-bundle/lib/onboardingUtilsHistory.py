import onboardingUtils
import logging
import sqlite3
from sqlite3 import Error
import vacfg_constants as const
import json

logger = logging.getLogger(__name__)

       

def create_connection(dbFileName):
    """ create a database connection to a SQLite database """
    conn = None
    try:
        conn = sqlite3.connect(dbFileName)
        return conn
    except Exception as e:
        print(e)

    return conn

def create_table(conn, create_table_sql, tableName):
    """ create a table from the create_table_sql statement
    :param conn: Connection object
    :param create_table_sql: a CREATE TABLE statement
    :return:
    """
    try:
        c = conn.cursor()
        dropQuery = 'DROP TABLE IF EXISTS %s;' % (tableName)
        c.execute(dropQuery)
        c.execute(create_table_sql)
    except Exception as e:
        print(e)

    return True


def create_history_table(dbFileName):

    conn = create_connection(dbFileName)
    sql_create_history_table = """ CREATE TABLE IF NOT EXISTS machinehistory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        deploymentId text NOT NULL,
        actionType text NOT NULL,
		requestId text NOT NULL,
		state text NOT NULL,
        description text,
        reasons text,
        requestedFor text NOT NULL,
        requestedBy text NOT NULL,
        tenant text NOT NULL,
        businessGroup text NOT NULL,
        dateCreated text NOT NULL,
        dateApproved text,
        dateCompleted text NOT NULL,
        requestCompletionState text NOT NULL,
        completionDetails text,
        requestData text NOT NULL,
        successful text NOT NULL,
        resourceName text NOT NULL,
        resourceId text NOT NULL,
        resourceActionName text NOT NULL  );
        """

    if conn is not None:
        print('Creating Table machinehistory')
        res = create_table(conn, sql_create_history_table, 'machinehistory')
        conn.close()

    if res:
    	return True
    else:
    	return False

def insertHistory(historyData, dbFileName, conn = None ):

    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    sql = ''' INSERT INTO machinehistory(deploymentId,actionType,requestId,state,
        description,reasons,requestedFor,requestedBy,tenant,businessGroup,dateCreated,
        dateApproved,dateCompleted,requestCompletionState,completionDetails,requestData,
        successful,resourceName,resourceId,resourceActionName)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);
    '''
    cur = conn.cursor()
    ret = cur.executemany(sql, historyData)
    conn.commit()

    if gotLocalConn:
        conn.close()
        
    return True

def getAllDeploymentHistoryData(dbFilename, project):
    conn = sqlite3.connect(dbFilename)

    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    logger.debug('DB filename: ' + dbFilename)

    sql = '''select distinct( machinehistory.id),  machinedata.deploymentName, machinedata.projectId, machinedata.deploymentId, machinehistory.description,
                    machinehistory.reasons,machinehistory.requestedFor,machinehistory.requestedBy,machinehistory.businessGroup,
                    machinehistory.dateCreated,machinehistory.dateApproved,machinehistory.requestCompletionState,machinehistory.completionDetails,
                    machinehistory.requestData,machinehistory.resourceName,machinehistory.resourceId,machinehistory.resourceActionName 
                    from machinehistory INNER JOIN machinedata on machinedata.deploymentId = machinehistory.deploymentId 
                    where machinedata.project = '%s'
                    order by machinehistory.deploymentId, machinehistory.dateCreated asc;
          ''' % (project)

    logger.debug(sql)
    print(sql)

    c.execute(sql)

    res = c.fetchall()
    logger.debug(res)
    conn.close()

    return res

def getHistoryActionName(dbFilename, project=None):
    conn = sqlite3.connect(dbFilename)

    c = conn.cursor()
    logger.debug('DB filename: ' + dbFilename)

    if project:
        sql = '''select distinct machinehistory.resourceActionName from machinedata INNER JOIN machinehistory on machinedata.deploymentId = machinehistory.deploymentId 
                        where machinedata.project = '%s';
              ''' % (project)
    else:
        sql = 'select distinct resourceActionName from machinehistory;'

    logger.debug(sql)
    print(sql)

    c.execute(sql)

    res = c.fetchall()
    logger.debug(res)
    conn.close()

    return res

def addCustomResourceActions(hostfqdn, token, actionNames, endpointLink):

    headers = {
        'Authorization': token
        }

    vraClient = onboardingUtils.RESTClient()

    reqUrl = const.vra8_create_resource_actions % (hostfqdn)
    

    payload = const.vra8_cust_resource_payload

    for actionName in actionNames:
        action = actionName[0]

        payload['name'] = 'bou-%s' % (action.lower().replace(' ', ''))
        payload['displayName'] = action
        payload['runnableItem']['endpointLink'] = endpointLink

        print("Createing action %s" % (payload['displayName']))
        response = vraClient.post(reqUrl, headers=headers, data=json.dumps(payload))
        # print (response)
    
        if response.status_code == 200:
            #print (response.content)
            data = response.json()
            print('Custom Resource action created %s' % action)
            logger.info('Custom Resource action created %s' % action)

        elif response.status_code == 400:
            data =response.json()
            if data.get('message', None):
                if 'already exists' in data['message']:
                    print('Custom Resource action already exists %s' % action)
                    logger.warning('Custom Resource action already exists %s' % action)
                    logger.warning(data['message'])
                else:
                    logger.error(data['message'])
                    print(data['message'])
                    print('Response Code: %s' % response.status_code )
            else:
                logger.error('Unable to create custom resource action')
                logger.error('Response Code: %s' % response.status_code )
                logger.error('Response: %s' % response.text )
                print('Unable to create custom resource action')
                print('Response Code: %s' % response.status_code )
                print('Response: %s' % response.text )
        else:
            logger.error('Unable to create custom resource action')
            logger.error('Response Code: %s' % response.status_code )
            logger.error('Response: %s' % response.text )
            print('Unable to create custom resource action')
            print('Response Code: %s' % response.status_code )
            print('Response: %s' % response.text )
            
    return 


def exportvRA8DeploymentHistory(hostfqdn, token, deployment):

    logger.info('Processing history for deployment: %s' % (deployment['name']))
    print('Processing history for deployment: %s' % (deployment['name']))
    resourceIdNameMap = {}
    for thisVM in deployment['resourceData']:
        resourceIdNameMap[thisVM['id']] = thisVM['properties']['resourceName']
    
    allRequests = []
    headers = { 'Authorization': token }

    vraClient = onboardingUtils.RESTClient()

    reqUrl = const.vra8_run_day2_action % (hostfqdn, deployment['id'])

    resp = vraClient.get(reqUrl, headers=headers)
    if resp.status_code == 200:
        data = resp.json()

        for thisRequest in data['content']:
            try:
                thisDeploymentId =  deployment['id']
                actionType = thisRequest.get('actionId', 'unknown')
                requestId = thisRequest.get('id', 'unknown')
                state = thisRequest.get('status', 'unknown')
                description = thisRequest.get('details', '')
                reasons = ''
                requestedFor = thisRequest.get('requestedBy', 'unknown')
                requestedBy = thisRequest.get('requestedBy', 'unknown')
                tenant = hostfqdn
                businessGroup = deployment['project']['name']
                requestCompletionState = thisRequest.get('status', 'unknown')
                completionDetails = json.dumps(thisRequest.get('outputs', 'none'))
                requestData = json.dumps(thisRequest.get('inputs', {'inputs':''}))
                if thisRequest.get('status', None) and thisRequest.get('status', None) == 'SUCCESSFUL':
                    successful = 'true'
                else:
                    successful = 'false'

                resourceId = str(thisRequest.get('resourceIds', []))
                resourceActionName = thisRequest.get('name', 'unknown')

                tmpDate = thisRequest.get('createdAt', '2020-03-17T17:35:19.504Z')
                if len(tmpDate) == 24:
                    dateCreated = tmpDate
                else:
                    dateCreated = tmpDate[:-3] + 'Z'

                tmpDate = thisRequest.get('approvedAt', None)
                dateApproved = ''
                if tmpDate:
                    if len(tmpDate) == 24:
                        dateApproved = tmpDate
                    else:
                        dateApproved = tmpDate[:-3] + 'Z'

                tmpDate = thisRequest.get('updatedAt', None)
                dateCompleted = ''
                if tmpDate:
                    if len(tmpDate) == 24:
                        dateCompleted = tmpDate
                    else:
                        dateCompleted = tmpDate[:-3] + 'Z'
                
                resourceName = ''
                tmpList = []
                for thisId in thisRequest.get('resourceIds', []):
                    tmpList.append(resourceIdNameMap[thisId]) if thisId in resourceIdNameMap else None

                resourceName = str(tmpList)

                 
                logger.debug("thisDeploymentId: %s, actionType: %s, requestId: %s, state: %s, description: %s, reasons: %s, requestedFor: %s, requestedBy %s, tenant: %s, businessGroup: %s, dateCreated: %s, dateApproved: %s, dateCompleted: %s, requestCompletionState: %s, completionDetails: %s, successful: %s, resourceName: %s, resourceId: %s, resourceActionName: %s" 
                        % (thisDeploymentId,actionType,requestId,state,description,reasons,requestedFor,requestedBy,tenant,businessGroup,dateCreated,dateApproved,dateCompleted,requestCompletionState,completionDetails,successful,resourceName,resourceId,resourceActionName))
                logger.debug(requestData)

                allRequests.append((thisDeploymentId,actionType,requestId,state,
                            description,reasons,requestedFor,requestedBy,tenant,businessGroup,dateCreated,
                            dateApproved,dateCompleted,requestCompletionState,completionDetails,requestData,
                            successful,resourceName,resourceId,resourceActionName))
            except Exception as e:
                print('Error extracting history entry for deployment %s' % (deployment['name']))
                print(thisRequest)
                print(e)
                logger.error('Error extracting history entry for deployment %s' % (deployment['name']))
                logger.error(thisRequest)
                logger.error(e) 

    else:
        logger.error('Unable to get deployment request histroy for deployment: %s' % deployment['id'])
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)

    return allRequests


