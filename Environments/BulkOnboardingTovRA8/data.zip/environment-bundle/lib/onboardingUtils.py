#!/usr/bin/env python3
import operator
import os
import sys
import json
import logging
import configparser
import time
import base64
import requests
import urllib.parse
import sqlite3
import csv
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
import yaml
from yaml.loader import SafeLoader

import vacfg_constants as const

requests.packages.urllib3.disable_warnings()

#CONFIG = "onboarding.ini"
logger = logging.getLogger(__name__)

def readConfig(section, CONFIG = "onboarding.ini"):

    config = configparser.ConfigParser()
    config.read(CONFIG)
    return config[section]

def buildUrl(baseUrl, endpoint, params):
    """baseUrl: string value of the protocol http/https and the fqdn of the target server
                must not include a trailing slash /
       endpoint: string of of the REST endpoint
       params: dict of key value pairs for each required parameter
    """

    base = '%s/%s' % (baseUrl, endpoint)
    queryParams = urllib.parse.urlencode(params)
    url = '%s?%s' % (base, queryParams)
    return url

def currentimeMilli():
    return round(time.time() * 1000)

def createConnection(db_file):
    """ create a database connection to a SQLite database """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Exception as e:
        logger.error(e)

    return conn

def createPlan(hostfqdn, token, description, planname, projectId, endpointId, organizationId, includeInProjectLimits=False, staticCustomProps={}):
    """
    Creates a New Plan
    """
    
    #need to add usePlacements: false for 8.10.1 and above

    payload = {
       "description": description,
       "name": planname,
       "projectId": projectId,
       "endpointIds": endpointId,
       "enableExtensibilityEvents": True,
       "organizationId": organizationId,
       "customProperties": staticCustomProps
    }

    if includeInProjectLimits:
        payload["usePlacements"] = includeInProjectLimits

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    vraClient = RESTClient()

    reqUrl = const.vra8_create_onboarding_plan % (hostfqdn)

    response = vraClient.post(reqUrl, headers=headers, data=json.dumps(payload))
    # print (response)
    
    if response.status_code == 200:
        #print (response.content)
        if response.json()['status'] == 'OK':
            return response.json()['documentSelfLink']
        else:
            logger.error('Unable to create deployment')
            logger.error('Response Code: %s' % response.status_code )
            logger.error('Response: %s' % response.text )
            logger.error('Payload: %s' %  payload)
            return None
    else:
        print('Unable to create deployment')
        print('Response Code: %s' % response.status_code )
        print('Response: %s' % response.text )
        print('Payload: %s' %  payload)
        logger.error('Unable to create deployment')
        logger.error('Response Code: %s' % response.status_code )
        logger.error('Response: %s' % response.text )
        logger.error('Payload: %s' %  payload)
        return None

def checkFileExists(filename):
    return os.path.isfile(filename)

def updateEndpointData(updateDataset, database):

    conn = createConnection(database)
    sql = ''' UPDATE machinedata set endpointId = ? where endpointFQDN = ?;
    '''

    logger.debug('Updating db with endpoint IDs')
    cur = conn.cursor()
    ret = cur.executemany(sql, updateDataset)
    conn.commit()
    conn.close()

def updateNSXEndpointData(updateDataset, database):

    conn = createConnection(database)
    sql = ''' UPDATE networkresourcedata set endpointId = ? where endpointFQDN = ?;
    '''

    logger.debug('Updating db with NSX endpoint IDs')
    cur = conn.cursor()
    ret = cur.executemany(sql, updateDataset)
    conn.commit()
    conn.close()

def createDeployment (hostfqdn, token, planLink, deploymentName, deploymentDescription, owner, allocate=False, migrationDID=None ):
    """
    Create Deployment
    """

    reqUrl = const.vra8_create_onboarding_deployment % (hostfqdn)

    payload = {
        "planLink": planLink,
        "name": deploymentName,
        "description": deploymentDescription,
        "owner": owner
    }

    if allocate:
        if not migrationDID:
            print('Adding Data to Deployment.')
            payload["tag"] = "__migration_did\npve"
        else:
            print('Adding Data to Deployment.')
            payload["tag"] = "__migration_did\n%s" % migrationDID


    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    vraClient = RESTClient()

    logger.debug(payload)
    response = vraClient.post(reqUrl, headers=headers, data=json.dumps(payload))

    if response.status_code == 200:
#        print (response.content)
        return response.json()['documentSelfLink']
    else:
        logger.error('Unable to create deployment')
        logger.error('Response Code: %s' % response.status_code )
        logger.error('Response: %s' % response.text )
        logger.error('Payload: %s' %  payload)
        return None

def createEmptyDeployment (hostfqdn, token, deploymentName, deploymentDescription, projectId ):
    """
    Create Deployment
    """
    url = "https://{}/iaas/api/deployments".format(hostfqdn)
    payload = {
        "name": deploymentName,
        "description": deploymentDescription,
        "projectId": projectId
    }

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    response = requests.request("POST", url, data=json.dumps(payload), headers=headers, verify=False)

    if response.status_code == 201:
        #print (response.content)
        return response.json()['id']
    else:
        logger.error('Unable to create deployment')
        logger.error('Response Code: %s' % response.status_code )
        logger.error('Response: %s' % response.text )
        logger.error('Payload: %s' %  payload)
        return None

def linkOnboardingDeployment(hostfqdn, token, deploymentLink, deploymentId):
     
    payload = {
        "consumerDeploymentLink": "/deployment/api/deployments/%s" % (deploymentId)
    }

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
    }

    url = 'https://%s%s' % (hostfqdn, deploymentLink)
    print (url)

    response = requests.request("PATCH", url, data=json.dumps(payload), headers=headers, verify=False)

    if response.status_code == 200:
        print (response.content)
        return response.json()['documentSelfLink']
    else:
        logger.error('Unable to create deployment')
        logger.error('Response Code: %s' % response.status_code )
        logger.error('Response: %s' % response.text )
        logger.error('Payload: %s' %  payload)
        return None

def findDeployment (hostfqdn, token, deploymentName, planLink):
    """
    """

    url = "https://{}/relocation/onboarding/deployment?$expand=true&$filter=name+eq+%27{}%27+and+planLink+eq+%27{}%27".format(hostfqdn,deploymentName,planLink)
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }
    response = requests.request("GET", url, headers=headers, verify=False)
    #print (url)
    #print (response.content)
    if response.status_code == 200:
#        print (response.content)
        if response.json()['totalCount'] == 1:
            return response.json()['documentLinks'][0]
        else:
            return None
    else:
        return None

def getDeployment (hostfqdn, token, deploymentLink):
    """
    """

    url = "https://{}{}".format(hostfqdn,deploymentLink)
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }
    response = requests.request("GET", url, headers=headers, verify=False)
    # print (response.content)
    if response.status_code == 200:
        return response.json()
    else:
        return None

def checkDeploymentPlan (hostfqdn, token, planLink, deploymentLink):
    """
    """

    depObj = getDeployment (hostfqdn, token, deploymentLink)
    if planLink == depObj.get('planLink'):
        return True
    else:
        return False

def getResourceName (hostfqdn, token, resourceId):
    """
    Find Resource Link
    """
    url = "https://{}/iaas/api/machines/{}".format(hostfqdn,resourceId)
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    response = requests.request("GET", url, headers=headers, verify=False)
    if response.status_code == 200:
        return response.json()['name']
    else:
        return None

def getMachineObjbyName(hostfqdn, token, top, skip, name, row, propstart, propskip, doProp):
    """
    """
    url = 'https://{}/iaas/api/machines?$top={}&$skip={}&$filter=name%20eq%20%27{}%27'.format(hostfqdn,top,skip,name)
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }
    response = requests.request("GET", url, headers=headers, verify=False)
    # print (response.content)
    if response.status_code == 200:
#        print (response.content)
        if response.json()['totalElements'] < 1:
            return None
        if response.json()['totalElements'] == 1:
            return response.json()['content'][0]
        if response.json()['totalElements'] > 1:
#            return response.content
            if doProp == True:
                propname = row[propstart:(len(row)):propskip]
                propvalue = row[propstart+1:(len(row)):propskip]
                if 'VirtualMachine.Admin.UUID' in propname:
                    for vmObj in response.json()['content']:
                        if vmObj.get('externalId') == urllib.parse.unquote(propvalue[propname.index('VirtualMachine.Admin.UUID')]):
                            return vmObj
                    return {}
                else:
                    return {}
            else:
                return {}
    else:
        return response.status_code

def findResource (hostfqdn, token, planLink, resourceName, machineObj):
    """
    Find Resource Link
    """
    url = "https://{}/relocation/api/wo/query-unmanaged-machine".format(hostfqdn)
    payload = {
        "planLink": planLink,
        "filters": [
            {
                "field": "NAME",
                "values": [ resourceName ]
            }
        ],
        "pageResultLimit": 100
    }

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    response = requests.request("POST", url, data=json.dumps(payload), headers=headers, verify=False)
    if response.status_code == 200:
        if response.json()['totalCount'] > 0:
            for resourceLink in response.json()['page']['documentLinks']:
                resourceId = resourceLink.split('/')[3]
                if resourceId == machineObj.get('id'):
                    return resourceLink
            return None
#                currentResourceName = getResourceName (hostfqdn, token, resourceId)
#                if currentResourceName == resourceName:
#                    return resourceLink
        else:
            return None
    else:
        return None

def addResource (hostfqdn, token, planLink, resourceName, resourceLink, deploymentLink, resprops):
    """
    Add Resource to Deployment
    """

    #added back in ruleLinks not sure why they were removed 27 Oct 2023 SL
    url = "https://{}/relocation/onboarding/resource".format(hostfqdn)
    payload = {
        "deploymentLink": deploymentLink,
        "ruleLinks": [ "/relocation/onboarding/rule/include",
                       "/relocation/onboarding/rule/managed"],
        "planLink": planLink,
        "resourceLink": resourceLink,
        "resourceName": resourceName,
        "customProperties": resprops,
        "options": ["DISABLE_CUSTOM_PROPERTIES_INHERITANCE"]
    }

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    response = requests.request("POST", url, data=json.dumps(payload), headers=headers, verify=False)
#    print (response)
    if response.status_code == 200:
        #print (response.content)
        resp = response.json()['documentSelfLink']
        return resp
    else:
        logger.error('Unable to create deployment')
        logger.error('Response Code: %s' % response.status_code )
        logger.error('Response: %s' % response.text )
        logger.error('Payload: %s' %  payload)
        return None

def executePlan (hostfqdn, token, planLink):
    """
    Execute Onboarding Plan
    """
    url = "https://{}/relocation/api/wo/execute-plan".format(hostfqdn)
    payload = {
        "planLink": planLink,
        "taskInfo": {
            "failure": {
                "details": [ "SHOULD_RETRY" ]
            },
        "isDirect": True,
        "stage": "CREATED"
        }
    }

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    response = requests.request("POST", url, data=json.dumps(payload), headers=headers, verify=False)
#    print (response)
    if response.status_code == 200:
#        print (response.text)
        return response.json()
    else:
        return None


def getExcutionPlan (hostfqdn, token, explan):
    """
    """
    url = 'https://{}/relocation/api/wo/execute-plan/{}'.format(hostfqdn,explan)
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }
    response = requests.request("GET", url, headers=headers, verify=False)
    # print (response.content)
    if response.status_code == 200:
        print (response.content)
        return response.json()
    else:
        return None

def getMachineProperties(dbFilename, machineId):
    conn = sqlite3.connect(dbFilename)

    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    logger.debug('DB Filename: ' + dbFilename)

    #propListSplit = propList.split(',')
    #tmpList = "','".join(propListSplit)
    #fmtList = "'%s'" % (tmpList)

    #sql = '''select propertyName, propertyValue from machineproperties where machineId = '%s' and propertyName in (%s);''' % (machineId, fmtList)

    sql = '''select newPropertyName, propertyValue from machineproperties where machineId = '%s';''' % (machineId)

    logger.debug(sql)
    c.execute(sql)

    res = c.fetchall()
    conn.close()

    logger.debug(res)
    return res

def buildProperties (dbFilename, machineId, owner, doProp, convertprop, allocate=False):
    """
    Build Virtual Machine Properties
    """
    if allocate:
        resprop = { "newOwner": owner, "__migration_did": "pve" }
    else:
        resprop = { "newOwner": owner }

    if doProp:
        allProp = getMachineProperties(dbFilename, machineId)

        for propObj in allProp:
            propertyName = propObj['newPropertyName']

            if propertyName in ['aria_export_tags']:
                continue

            if convertprop:
                propertyName = propObj['newPropertyName'].replace(".","_")
            resprop[propertyName] = urllib.parse.unquote(propObj['propertyValue'])

    return resprop

def getDeploymentActionStatus(hostfqdn, token, deploymentId, actionId):
    '''
    Check if a spacific day 2 action is available for a deployment
    '''
    url = 'https://{}/deployment/api/deployments/{}/actions/{}'.format(hostfqdn,deploymentId,actionId)
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }
    response = requests.request("GET", url, headers=headers, verify=False)

    if response.status_code == 200:
        return response.json()['valid']
    else:
        return None

def getActionRequestStatus(hostfqdn, token, deploymentId, requestId):
    '''
    checks status of day 2 action
    '''
    url = 'https://{}/deployment/api/deployments/{}/requests/{}'.format(hostfqdn,deploymentId,requestId)
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }
    response = requests.request("GET", url, headers=headers, verify=False)

    if response.status_code == 200:
        return response.json()['status']
    else:
        return None

### Change Lease Date

def changeLeaseDate (hostfqdn, token, deploymentId, newDate):
    """
    Invokes Day 2 action to set leases date
    """
    url = "https://{}/deployment/api/deployments/{}/requests".format(hostfqdn,deploymentId)
    if newDate == None:
        payload = {"actionId": "Deployment.ChangeLease","inputs": { }}
    else:
        payload = {
                    "actionId": "Deployment.ChangeLease",
                    "inputs": {
                        "Lease Expiration Date": newDate
                    },
                    "reason": "Onboarding from vRA 7"
                  }

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }
    response = requests.request("POST", url, data=json.dumps(payload), headers=headers, verify=False)
#    print (response)
    if response.status_code == 200:
        return response.json()['id']
    else:
        return None

def setLeaseDate (hostfqdn, token, deploymentId, actionId, newDate):

# Check if action is available
    actionStatus = getDeploymentActionStatus(hostfqdn, token, deploymentId, actionId)

    while actionStatus != True:
        time.sleep(10)
        actionStatus = getDeploymentActionStatus(hostfqdn, token, deploymentId, actionId)

    # Invoke Day 2 actioin Change Lease Date
    requestId = changeLeaseDate (hostfqdn, token, deploymentId, newDate)
    # Check Request Status
    requestStatus = getActionRequestStatus(hostfqdn, token, deploymentId,requestId)
    requestStatusList = ['ABORTED', 'SUCCESSFUL', 'FAILED']
    while requestStatus not in requestStatusList:
        print ('Request ID: ', requestId, requestStatus)
        time.sleep(10)
        requestStatus = getActionRequestStatus(hostfqdn, token, deploymentId,requestId)
    return requestStatus

def checkProjectUsers(projectUsers, newOwner):
    '''
    Checks New Owner with current list of users in Project
    '''
    userExists = False
    for user in projectUsers:
        if user['email'] == newOwner:
            userExists = True
            break
    return userExists

def getProjectUsers(hostfqdn, token, projectId):
    '''
    Query's Project for Administrator and Member Users
    '''
    url = 'https://{}/iaas/api/projects/{}'.format(hostfqdn,projectId)
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }
    response = requests.request("GET", url, headers=headers, verify=False)
    # print(response.content)
    if response.status_code == 200:
        return response.json()['administrators'] + response.json()['members']
    else:
        return None

def validateUser(hostfqdn, token, OrgId, newOwner):
    '''
    Validate if a user is in vRA
    '''
    url = 'https://{}/csp/gateway/am/api/users/{}/orgs/{}/info'.format(hostfqdn,newOwner, OrgId)
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }
    response = requests.request("GET", url, headers=headers, verify=False)
    print (response.content)
    if response.status_code == 404:
#        return response.json()['serverMessage']
        return False
    if response.status_code == 200:
#        return response.json()['user']['id']
        return True
    else:
        return False

def changeOwnerAction (hostfqdn, token, deploymentId, newOwner):
    """
    This function invokes day 2 action Change Owner
    """
    url = "https://{}/deployment/api/deployments/{}/requests".format(hostfqdn,deploymentId)
    payload = {
                "actionId": "Deployment.ChangeOwner",
                "inputs": {
                    "New Owner": newOwner
                },
                "reason": "Onboarding from vRA 7"
            }

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }
    response = requests.request("POST", url, data=json.dumps(payload), headers=headers, verify=False)
#    print (response)
    if response.status_code == 200:
        return response.json()['id']
    else:
        return None


def addUsertoProject (hostfqdn, token, projectId, newOwner):
    """
    add user to project
    """
    url = "https://{}/project-service/api/projects/{}/principals".format(hostfqdn,projectId)
    payload = {
                "modify": [
                            {
                                "email": newOwner,
                                "role": "member",
                                "type": "user"
                            }
                          ],
                "remove": [ ]
              }

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }
    response = requests.request("PATCH", url, data=json.dumps(payload), headers=headers, verify=False)
#    print (response.content)
    if response.status_code == 200:
        return response.content
    else:
        return None

def removeUserfromProject (hostfqdn, token, projectId, members):
    """
    Remove user from project
    """
    reqUrl = "https://{}/project-service/api/projects/{}/principals".format(hostfqdn,projectId)

    logger.debug('Request URL: %s' % (reqUrl))
    #print('Request URL: %s' % (reqUrl))

    removeList = []

    for thisMember in members:
        removeList.append( {
                                "email": thisMember,
                                "role": "member",
                                "type": "user"
                            } )

    payload = {
                "remove": removeList
              }

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    resp = vraClient.patch(reqUrl, headers=headers, data=json.dumps(payload))

    if resp.status_code == 200:
        data = resp.json()
        #print(data)
        logger.debug(data)

        return True
    else:
        return None

def changeOwner (hostfqdn, token, orgId, projectId, deploymentId, actionId, newOwner):
    """
    Change Owner
    """
    # Get list of current users in the Project
    projectUsers = getProjectUsers(hostfqdn, token, projectId)
    # Check if user is already assigned in the project
    userExists = checkProjectUsers(projectUsers, newOwner)
    # If user is not in the project then add user to project
    if userExists != True:
        userstatus = validateUser(hostfqdn, token, orgId, newOwner)
        print(userstatus)
        if userstatus == True:
            projectStatus = addUsertoProject (hostfqdn, token, projectId, newOwner)
            time.sleep(5)

    # Check is action is currently available for the deployment
    actionStatus = getDeploymentActionStatus(hostfqdn, token, deploymentId, actionId)
    if actionStatus == True:
        # execute day 2 action change owner
        requestId = changeOwnerAction (hostfqdn, token, deploymentId, newOwner)
        # query for request status
        requestStatus = getActionRequestStatus(hostfqdn, token, deploymentId,requestId)
        requestStatusList = ['ABORTED', 'SUCCESSFUL', 'FAILED']
        while requestStatus not in requestStatusList:
            print ('Request ID: ', requestId, requestStatus)
            time.sleep(10)
            requestStatus = getActionRequestStatus(hostfqdn, token, deploymentId,requestId)

    # remove user if it was added above
    if userExists != True:
        projectStatus = removeUserfromProject (hostfqdn, token, projectId, newOwner)
    return requestStatus



def getToken(hostname, username, password, component, domain=None, tenant=None):
    if component == 'vra76':
        if not tenant:
            logger.error('Tenant value must be supplied for vRA 7.x login')
            return None

        logger.info('Connectiong to tenant: %s on vRA host: %s' % (tenant, hostname))

        payload = { "username":username, "password":password, "tenant":tenant }
        identity_url = 'https://%s/%s' % (hostname, const.vra76_identity_url)
        vraClient = RESTClient()
        resp=vraClient.post(identity_url, data=json.dumps(payload))
        
        if resp.status_code == 200:
            data = resp.json()
            token = data["id"]
            logger.info('vRA 7.6 token aquired')
        else:
            logger.error('Unable to aquire vRA 7.6 token')
            logger.error('Response Code: %s' % resp.status_code )
            logger.error('Response: %s' % json.dumps(resp.json()) )
            raise ValueError('Error aquiring token: response code: %s, response: %s' % (resp.status_code, json.dumps(resp.json())))
        
        return token
 
    elif component in ['vra8_refresh', 'vra8', 'vra8_cloud']:
        refreshurl = 'https://%s/%s' % (hostname,const.vra8_refresh_token_url)
        payload = { "username":username,"password":password}
        if domain:
            payload['domain'] = domain
        vraClient = RESTClient()
        if component in ['vra8_refresh', 'vra8']:
            resp = vraClient.post(refreshurl, data=json.dumps(payload))
            if resp.status_code == 200:
                data = resp.json()
                refresh_token = data['refresh_token']
                logger.info('vRA 8 Refresher token aquired')
            else:
                logger.error('Unable to aquire vRA 8 refresh token')
                logger.error('Response Code: %s' % resp.status_code )
                logger.error('Response: %s' % json.dumps(resp.json()) )
                raise ValueError('Error aquiring token: response code: %s, response: %s' % (resp.status_code, json.dumps(resp.json())))
        if component == 'vra8_refresh':
            return refresh_token
        
        if component == 'vra8_cloud':
            refresh_token = password

        payload = { "refreshToken":refresh_token }
        #if component == 'vra8':
        accessUrl = 'https://%s/%s' % ( hostname, const.vra8_access_token_url)
        #elif component == 'vra8_cloud':
        #    accessUrl = 'https://%s/%s' % ( hostname, const.vra8_csp_token_url)

        resp = vraClient.post(accessUrl, data=json.dumps(payload)) 
        if resp.status_code == 200:
            data = resp.json()
            access_token = data['token']
            logger.info('vRA 8 Access token aquired')
        else:
            logger.error('Unable to aquire access token')
            logger.error('Response Code: %s' % resp.status_code )
            logger.error('Response: %s' % json.dumps(resp.json()))
            raise ValueError('Error aquiring token: response code: %s, response: %s' % (resp.status_code, json.dumps(resp.json())))
        return access_token

    elif component in ['vro8', 'vro76']:
        data_string = '%s:%s' % (username, password)
        data_bytes = data_string.encode("utf-8")
        authStr = base64.b64encode(data_bytes)
        return authStr
    elif component == 'vracloud':
        
        logger.info('Connectiong to vRA Cloud at %s ' % (hostname))

        payload = { "refreshToken": password }
        loginURL = 'https://%s/%s' % (hostname, const.vra8_access_token_url)
        vraClient = RESTClient()
        resp=vraClient.post(loginURL, data=json.dumps(payload))

        if resp.status_code == 200:
            data = resp.json()
            token = data["token"]
            logger.info('vRA Cloud token aquired')
        else:
            logger.error('Unable to aquire vRA Cloud token')
            logger.error('Response Code: %s' % resp.status_code )
            logger.error('Response: %s' % resp.text )
            raise ValueError('Error aquiring token: response code: %s, response: %s' % (resp.status_code, json.dumps(resp.json())))

        return token
    elif component == 'vracloudcsp':

        logger.info('Connectiong to vRA Cloud at %s ' % (hostname))

        payload = {}
        loginURL = 'https://%s/%s?refresh_token=%s' % (hostname, const.vra8_csp_token_url,password)
        vraClient = RESTClient()

        headers = {
        'accept': "application/json",
        'content-type': "aapplication/x-www-form-urlencoded"}
        resp=vraClient.post(loginURL, data=json.dumps(payload), headers=headers)

        if resp.status_code == 200:
            data = resp.json()
            token = data["access_token"]
            logger.info('vRA Cloud CSP token aquired')
        else:
            logger.error('Unable to aquire vRA Cloud token')
            logger.error('Response Code: %s' % resp.status_code )
            logger.error('Response: %s' % resp.text )
            raise ValueError('Error aquiring token: response code: %s, response: %s' % (resp.status_code, json.dumps(resp.json())))

        return token


class RESTClient(object):
    """
    Description - Class for REST API. contains methods for all REST calls.

    """
    def __init__(self, username=None, password=None):
        """
        Description:
            init for initializing class
        Parameters:
            username -   User name to use when connecting to host(STRING)
            password -   Password to use when connecting to host(STRING)
        """

        self.auth = None

        #Default headers type, can be updated, based on provided headers value.
        self.headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
        self.verify = False

    def get(self, url, headers=None, **kwargs):
        """
        Description:
            This method contains handler for REST GET call.
        Parameters:
            url - Complete location url path for running for REST call(STRING)
            headers - (OPTIONAL) Content-Type: application/(json/xml)
            kwargs - (OPTIONAL) parameters used in REST request.

        Returns:
            Response object
        """
        return self.execute('GET', url, headers=headers, **kwargs)

    def post(self, url, headers=None, **kwargs):
        """
        Description:
            This method contains handler for REST POST call.
        Parameters:
            url - Complete location url path for running for REST call(STRING)
            headers - (OPTIONAL) Content-Type: application/(json/xml)
            kwargs - (OPTIONAL) parameters used in REST request.

        Returns:
            Response object
        """

        return self.execute("POST", url, headers=headers, **kwargs)

    def put(self, url, headers=None, **kwargs):
        """
        Description: This method contains handler for REST PUT call.
        Parameters:  url - Complete location url path for running for REST call(STRING)
                     headers - (OPTIONAL) Content-Type: application/(json/xml)
                     kwargs - (OPTIONAL) parameters used in REST request.
        Returns:    Response object
        """
        return self.execute("PUT", url, headers=headers, **kwargs)

    def patch(self, url, headers=None, **kwargs):
        """
        Description: This method contains handler for REST PATCH call.
        Parameters:  url - Complete location url path for running for REST call(STRING)
                     headers - (OPTIONAL) Content-Type: application/(json/xml)
                     kwargs - (OPTIONAL) parameters used in REST request.
        Returns:    Response object
        """
        return self.execute("PATCH", url, headers=headers, **kwargs)

    def delete(self, url, headers=None, **kwargs):
        """
        Description: This method contains handler for REST DELETE call.
        Parameters:  url - Complete location url path for running for REST call(STRING)
                     headers - (OPTIONAL) Content-Type: application/(json/xml)
                     kwargs - (OPTIONAL) parameters used in REST request.
        Returns:    Response object
        """
        return self.execute("DELETE", url, headers=headers, **kwargs)

    def execute(self, method, url, headers=None, **kwargs):
        """
        Description:
            Will perform HTTP call support GET, HEAD, POST, PUT and DELETE.
        Parameters:
            method - Type of request method.
            url - Complete location url path for running for REST call(STRING)
            headers - (OPTIONAL) Content-Type: application/(json/xml)
            kwargs - (OPTIONAL) parameters used in REST request.

        Returns:
            Response object
        """
        try:
            #Update headers with new header values
            logger.info("%s request URL: %s", method, url)
            reqheaders = self.headers or {}
            reqheaders.update(headers or {})

            responsdata = requests.request(method, url, headers=reqheaders, auth=self.auth, verify=self.verify,
                                           **kwargs)
            return responsdata

        except Exception as ex:
            logger.exception("Request Exception : %s", ex)
            raise

    def uploadFile(self, url, enableLog=True, **kwargs):
        """
        Description:
            Will perform HTTP call for POST request for uploading file.
        Parameters:
            url - Complete location url path for running for REST call(STRING)
            kwargs - (OPTIONAL) parameters used in REST request.
            enableLog - Modifying logs when required based on input parameter (BOOLEAN)

        Returns:
            Response object
        """

        try:
            if enableLog:
                logger.info("POST request URL: %s", url)
            else:
                logger.info("Calling POST request, url is not logged as it contains password")
            responsdata = requests.request("POST", url, auth=self.auth, verify=self.verify, **kwargs)
            return responsdata

        except Exception as ex:
            logger.exception("Request Exception : %s", ex)
            raise

def removeUserfromProject (hostfqdn, token, projectId, members):
    """
    Remove user from project
    """
    reqUrl = "https://{}/project-service/api/projects/{}/principals".format(hostfqdn,projectId)

    logger.debug('Request URL: %s' % (reqUrl))
    #print('Request URL: %s' % (reqUrl))

    removeList = []

    for thisMember in members:
        removeList.append( {
                                "email": thisMember,
                                "role": "member",
                                "type": "user"
                            } )

    payload = {
                "remove": removeList
              }

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    vraClient = RESTClient()

    resp = vraClient.patch(reqUrl, headers=headers, data=json.dumps(payload))

    if resp.status_code == 200:
        data = resp.json()
        #print(data)
        logger.debug(data)

        return True
    else:
        return None

def changeOwner (hostfqdn, token, orgId, projectId, deploymentId, actionId, newOwner):
    """
    Change Owner
    """
    # Get list of current users in the Project
    projectUsers = getProjectUsers(hostfqdn, token, projectId)
    # Check if user is already assigned in the project
    userExists = checkProjectUsers(projectUsers, newOwner)
    # If user is not in the project then add user to project
    if userExists != True:
        userstatus = validateUser(hostfqdn, token, orgId, newOwner)
        print(userstatus)
        if userstatus == True:
            projectStatus = addUsertoProject (hostfqdn, token, projectId, newOwner)
            time.sleep(5)

    # Check is action is currently available for the deployment
    actionStatus = getDeploymentActionStatus(hostfqdn, token, deploymentId, actionId)
    if actionStatus == True:
        # execute day 2 action change owner
        requestId = changeOwnerAction (hostfqdn, token, deploymentId, newOwner)
        # query for request status
        requestStatus = getActionRequestStatus(hostfqdn, token, deploymentId,requestId)
        requestStatusList = ['ABORTED', 'SUCCESSFUL', 'FAILED']
        while requestStatus not in requestStatusList:
            print ('Request ID: ', requestId, requestStatus)
            time.sleep(10)
            requestStatus = getActionRequestStatus(hostfqdn, token, deploymentId,requestId)

    # remove user if it was added above
    if userExists != True:
        projectStatus = removeUserfromProject (hostfqdn, token, projectId, [newOwner])
    return requestStatus

def getOnboardinData(dbFilename, project, includeSecurityGroups=False):
    conn = sqlite3.connect(dbFilename)

    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    logger.debug('DB filename: ' + dbFilename)

    sql = '''select project, projectId, endpointId, deploymentName, deploymentDescription, machineName, machineId, vra8MachineId, cloudTemplateName, cloudTemplateId, newOwner as owner, deploymentDate from machinedata where import = 'yes' and project = '%s' order by deploymentName desc;''' % (project)

    logger.debug(sql)

    c.execute(sql)

    res = c.fetchall()
    
    if includeSecurityGroups:
        sql = '''select project, projectId, endpointId, deploymentName, deploymentDescription, resourceName as machineName, resourceId as machineId, vra8MachineId, cloudTemplateName, cloudTemplateId, newOwner as owner, deploymentDate from networkresourcedata where import = 'yes' and project = '%s' order by deploymentName desc;''' % (project)
        
        logger.debug(sql)

        c.execute(sql)

        resNet = c.fetchall()

        res += resNet

    logger.debug(res)

    conn.close()

    return res

def getLoggedInOrg(vra8Conn, token, target):
    headers = {'Authorization': '%s' % (token)}

    vraClient = RESTClient()
    if target == 'cloud':
        #move this url to constants file
        reqUrl = "https://%s/csp/gateway/am/api/auth/api-tokens/details" % (vra8Conn['cspfqdn'])

        logger.debug('Request URL: %s' % (reqUrl))
        print('Request URL: %s' % (reqUrl))

        payload ={ "tokenValue": vra8Conn['refreshToken']}
        resp = vraClient.post(reqUrl, headers=headers, data=json.dumps(payload))

    else:
        reqUrl = const.vra8_get_loggedin_org % (vra8Conn['hostfqdn'])

        logger.debug('Request URL: %s' % (reqUrl))
        #print('Request URL: %s' % (reqUrl))

        resp = vraClient.get(reqUrl, headers=headers)

    if resp.status_code == 200:
        data = resp.json()
        #print (data)
        if target == 'cloud':
            thisOrg = data['orgId']
        else:
            thisOrg = data['refLinks'][0].replace('/csp/gateway/am/api/orgs/','')
        return thisOrg
    else:
        logger.error('Unable to get org')
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)
        return None

def getAllEndpointsforProject (dbFilename, projectId, includeSecurityGroups=False):
    conn = sqlite3.connect(dbFilename)

    c = conn.cursor()
    logger.debug('SQL Lite DB Filename: ' + dbFilename)

    sql = '''select distinct endpointId from machinedata where projectId = '%s';''' % (projectId)

    logger.debug(sql)
    c.execute(sql)

    res = c.fetchall()

    if includeSecurityGroups:
        sql = '''select distinct endpointId from networkresourcedata where projectId = '%s';''' % (projectId)

        logger.debug(sql)
        c.execute(sql)

        resNSX = c.fetchall()

        res += resNSX

    conn.close()
    epList = []
    for item in res:
        epList.append(item[0])

    return epList

def clearVMValidationData(dbFilename, validation=True, includeSecurityGroups=False):
    conn = sqlite3.connect(dbFilename)

    blankVMData = False
    blankProps = False

    c = conn.cursor()

    sql = '''update machinedata set vra8MachineId = NULL , endpointId = NULL;'''

    logger.debug(sql)

    c.execute(sql)
    conn.commit()

    if c.rowcount > 0:
        blankVMData =  True

    if validation:
        sql = '''update machineproperties set newPropertyName = NULL;'''

        logger.debug(sql)

        c.execute(sql)
        conn.commit()

    sql = '''select COUNT(*) as hasData from machinedata where vra8MachineId IS NOT NULL;'''
    cur = conn.cursor()
    ret = cur.execute(sql)

    notBlank = cur.fetchall()   
    
    #print(notBlank[0][0])
    if int(notBlank[0][0]) > 0:
        print('Unable to clear validation data')
        logger.error('Unable to blank security group data')
    else:
        blankVMData =  True

    sql = '''select COUNT(*) as machineCount from machinedata where machineId IS NOT NULL;'''
    cur = conn.cursor()
    ret = cur.execute(sql)

    machines = cur.fetchall()   
    
    #print(machines[0][0])
    if int(machines[0][0]) == 0:
        print('################################################################')
        print('NO MACHINE IN THE DATASET, MACHINE TABLE IS EMPTY')
        print('IF MACHINES ARE EXPECTED TO BE PRESENT RUN DATA COLLECTION AGAIN')
        print('################################################################')
        logger.warning('NO MACHINE IN THE DATASET, MACHINE TABLE IS EMPTY')

    conn.close() 

    return blankVMData

def processUserObj(obj):
    data = {'user':[],'group':[]}
    for thisItem in obj:
        data[thisItem['type']].append(thisItem['email'])

    return data['user'], data['group']

def processProject(respBody, projectData, projectNames):

    for thisProject in respBody:
        if thisProject['name'] not in projectNames:
            continue

        usersA, groupsA = processUserObj(thisProject['administrators'])
        usersU, groupsU = processUserObj(thisProject['members'])


        if thisProject['name'] in projectData.keys():
            projectData[thisProject['name']]['groups'] = thisProject['name']['groups'] + groupsA + groupsU
            projectData[thisProject['name']]['users'] = thisProject['name']['groups'] + usersA + usersU
        else:
            projectData[thisProject['name']] = {'name': thisProject['name'],
                                             'id': thisProject['id'],
                                             'properties': thisProject['properties'],
                                             'users': usersA + usersU,
                                             'groups': groupsA + groupsU}

    return projectData

def verifyProjects(database, hostname, token, includeSecurityGroups=False):

    pgSize = 500
    conn = createConnection(database)
    cur = conn.cursor()
    cur.execute('SELECT distinct project from machinedata where project is not NULL;')
    projectNames = []
    for res in cur:
        projectNames.append(res[0])

    if includeSecurityGroups:
        cur.execute('SELECT distinct project from networkresourcedata where project is not NULL;')
        for res in cur:
            projectNames.append(res[0])

    conn.close()
    
    if len(projectNames) > 0:
        print('Project Names to verify: ' + ','.join(projectNames))
        logger.debug('Project Names to verify: ' + ','.join(projectNames))
    else:
        print('No Project Names found in dataset')
        logger.error('No Project Names found in dataset')
        return False, {}, None

    headers = {'Authorization': '%s' % (token)}
    reqUrl = '%s?page=%s&size=%s' % (const.vra8_get_all_projects % (hostname), 0, pgSize)

    logger.debug('Request URL: %s' % (reqUrl))
    #print('Request URL: %s' % (reqUrl))

    vraClient = RESTClient()
    resp = vraClient.get(reqUrl, headers=headers)
    projectData = {}

    if resp.status_code == 200:
        data = resp.json()
        logger.debug('Processing Page 0 of project response.')
        projectData = processProject(data['content'], {}, projectNames)

        pgCounter = 1
        if 'totalPages' in resp.json().keys():
            while pgCounter < resp.json()['totalPages']:
                print('going to get page %s' % pgCounter)
                reqUrl = '%s?page=%s&size=%s' % (const.vra8_get_all_projects % (hostname), pgCounter, pgSize)

                resp = vraClient.get(reqUrl, headers=headers)
                if resp.status_code == 200:
                    data = resp.json()
                    logger.debug('Processing Page %s of project response.' % pgCounter)
                    projectData = processProject(data['content'], projectData, projectNames)
                else:
                    logger.error('Bad response')
                    logger.error(resp.text)

                if len(projectData.keys()) == len(projectNames):
                    print('All project found.')
                    logger.info('All project found.')
                    pgCounter = 5000
                else:
                    pgCounter = pgCounter + 1
        else:
            logger.error('No pageable response')
    else:
        logger.error('Unable to get list of projects')
        logger.error(resp.text)

    logger.debug(projectData)

    projectsVerified = False

    diff = set(projectNames) - set(projectData.keys())
    if len(diff) == 0:
        projectsVerified = True
    else:
        print('Unable to find projects: ' + ','.join(diff))
        logger.debug('Unable to find projects: ' + ','.join(diff))

    return projectsVerified, projectData, diff

def getGroupId(gpName, hostname, token, target, orgId=None):

    headers = {'Authorization': '%s' % (token)}

    splitName = gpName.split('@')
    if splitName[1] == 'System Domain':
        gpName = splitName[0]
    else:
        gpName = '%s@%s' % (splitName[0], splitName[1])

    if target == 'onprem':
        reqUrl = const.vra8_group_search % (hostname, gpName)
    else:
        reqUrl = const.vracloud_group_search % (hostname, orgId, gpName)

    logger.debug('Request URL: %s' % (reqUrl))
    #print('Request URL: %s' % (reqUrl))

    vraClient = RESTClient()
    resp = vraClient.get(reqUrl, headers=headers)

    if resp.status_code == 200:
        data = resp.json()
        logger.debug(data)
        if target == 'onprem':
            if data['totalResults'] == 1:
                #print('found 1 result')
                return data['results'][0]['id']
            else:
                logger.debug('Group ID not found in onprem search for %s' % gpName)
                logger.debug(data)
                return None
        elif target == 'cloud':
            if len(data['results']) == 1:
                return data['results'][0]['id']
            else:
                logger.debug('Group ID not found in cloud search for %s' % gpName)
                logger.debug(data)
                return None
    else:
        logger.error('Unable to get group data for: %s' % (gpName))
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)

    return None

def checkUserGroupMembership (hostname, token, verifiedUsersCache, projectGroups, projectName, data, user, groupCache, target='onprem', orgId=None ):

    if not verifiedUsersCache.get(user, None):
        verifiedUsersCache[user] = {'id':data['user']['acct'], 'groups':data['user']['groups'], 'orgOwner': False}

    print('Checking Group Membership')

    validUser = False
    if len(projectGroups) == 0:
        print('No Groups configured on project %s. User %s not in a valid group. ' % (projectName, user))
        logger.debug('No Groups configured on project %s. ' % (projectName))
        validUser = False

    for gpName in projectGroups:
        logger.debug('Checking Group %s for member %s' % (gpName, user))
        gpId = getGroupId(gpName, hostname, token, target, orgId)

        if not gpId:
            logger.debug('Unable to find groupId for group %s' % (gpName))
            continue

        groupCache[gpName] = gpId
        groupCache[gpId] = gpName

        if gpId in data['user']['groups']:
            print('Found valid group memebership for user %s in project %s' % (user, projectName))
            logger.debug('Found valid group memebership for user %s in project %s' % (user, projectName))
            validUser = True
            break
        else:
            print('User %s is not in this group %s' % (user, gpName))
            logger.debug('User %s is not in this group %s' % (user, gpName))
            validUser = False

    return validUser, verifiedUsersCache, groupCache

def updateOwnerData(updateDataset, database):

    conn = createConnection(database)
    sql = ''' UPDATE machinedata set newOwner = ? where newOwner = ?;
    '''

    logger.debug(sql)
    logger.debug('Updating db with Validated Owner Name')

    cur = conn.cursor()
    ret = cur.executemany(sql, updateDataset)
    conn.commit()
    conn.close()

def getCloudGroupsforUser(hostname, token, org, user):

    headers = {'Authorization': '%s' % (token)}

    reqUrl = const.vracloud_get_users_groups % (hostname, user, org)

    logger.debug('Request URL: %s' % (reqUrl))
    #print('Request URL: %s' % (reqUrl))

    vraClient = RESTClient()
    resp = vraClient.get(reqUrl, headers=headers)

    if resp.status_code == 404:
        logger.warning('No groups found for user')
        logger.warning(resp.text)
        return []

    if resp.status_code == 200:
        data = resp.json()
        allGroups = []
        for thisGroup in data['groups']:
            allGroups.append(thisGroup['id'])
        return allGroups
    else:
        return []

def checkOrgOwner(hostname, userId, org, token, target):
    orgOwner = False
    
    headers = {'Authorization': '%s' % (token)}
    vraClient = RESTClient()

    #need to do multi processing here 
    reqUrl = const.vra8_check_user_roles % (hostname, userId, org)
    logger.debug('Request URL: %s' % (reqUrl))
    resp = vraClient.get(reqUrl, headers=headers)

    if resp.status_code == 200:
        data = resp.json()
        #print(data)
        logger.debug(data)
        for thisRole in data:
            if thisRole['displayName'] == 'Organization Owner':
                orgOwner = True
                break
    else:
        logger.error('Unable to get user role data')
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)

    if orgOwner:
        print('User ID %s is Org Owner.' % (userId))
        logger.debug('User ID %s is Org Owner.' % (userId))
    else:
        print('User ID %s is NOT Org Owner.' % (userId))
        logger.debug('User ID %s is NOT Org Owner.' % (userId))

    return orgOwner

def processUserforCacheBuilder(hostname, thisOwner, org, token, target, allowOrgOwner=False):
    
    headers = {'Authorization': '%s' % (token)}
    vraClient = RESTClient()

    #need to do multi processing here 
    reqUrl = const.vra8_user_search % (hostname, thisOwner, org)

    logger.debug('Request URL: %s' % (reqUrl))
    #print('Request URL: %s' % (reqUrl))
    
    thisCacheUser = {}

    resp = vraClient.get(reqUrl, headers=headers)

    if resp.status_code == 200:
        data = resp.json()
        logger.debug(data)

        user = data['user']['acct']

        if target == 'cloud':
            cloudGroups = getCloudGroupsforUser(hostname, token, org, user)
            data['user']['groups'] = cloudGroups

        if data['user'].get('id', None):
            thisCacheUser[user] = {'id':data['user']['acct'], 'groups':data['user']['groups'], 'vraId': data['user']['id'], 'orgOwner': False}
        elif data['user'].get('userId', None):
            thisCacheUser[user] = {'id':data['user']['acct'], 'groups':data['user']['groups'], 'vraId': data['user']['userId'], 'orgOwner': False}
        else:
            thisCacheUser[user] = {'id':data['user']['acct'], 'groups':data['user']['groups'], 'vraId': '', 'orgOwner': False}

        if allowOrgOwner:
            if data['user'].get('id', None):
                thisCacheUser[user]['orgOwner'] = checkOrgOwner(hostname, data['user']['id'], org, token, target)
            elif data['user'].get('userId', None):
                thisCacheUser[user]['orgOwner'] = checkOrgOwner(hostname, data['user']['userId'], org, token, target)
            else:
                thisCacheUser[user]['orgOwner'] = False

    elif resp.status_code == 404 and '@' in thisOwner:
        logger.warning('Unable to find user: %s' % (thisOwner))
        logger.warning('Going to try and find user without Domain suffix')

        shortUser = thisOwner.split('@')[0]
        
        thisCacheUser = processUserforCacheBuilder(hostname, shortUser, org, token, target, allowOrgOwner)
            
    elif resp.status_code == 404:
        logger.warning('Unable to find user: %s' % (thisOwner))
        logger.warning('User %s is not a valid vRA 8 user, please check if user is configured in VIDM' % (thisOwner))
        print('\x1b[1;37;41m' + '!!! WARNING !!!' + '\x1b[0m')
        print('Unable to find user: %s' % (thisOwner))
        logger.error(resp.text)

    else:
        logger.error('Unable to get user data for: %s' % (thisOwner))
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)

    return thisCacheUser

def buildUserCache(database, projectData, vra8Conn, token, org, target='onprem', projectName=None, allowOrgOwner=False, includeSecurityGroups=False):

    if projectName:
        sql = '''SELECT distinct newOwner from machinedata where project = '%s' and newOwner is not NULL;''' % (projectName)
    else:
        sql = 'SELECT distinct newOwner from machinedata where newOwner is not NULL;'

    conn = createConnection(database)
    conn.row_factory = lambda cursor, row: row[0]
    cur = conn.cursor()

    logger.debug(sql)
    cur.execute(sql)

    allOwners = cur.fetchall()

    if includeSecurityGroups:
        if projectName:
            sql = '''SELECT distinct newOwner from networkresourcedata where project = '%s' and newOwner is not NULL;''' % (projectName)
        else:
            sql = 'SELECT distinct newOwner from networkresourcedata where newOwner is not NULL;'

        cur = conn.cursor()

        logger.debug(sql)
        cur.execute(sql)

        allNetOwners = cur.fetchall()

        allOwners += allNetOwners

    conn.close()

    logger.debug(allOwners)
    logger.debug(len(allOwners))

    verifiedUsersCache = {}

    if not org:
        logger.error('Unable to get org. PLease review the logs')
        System.exit(1)

    if target == 'onprem':
        hostname = vra8Conn['hostfqdn']
    else:
        hostname = vra8Conn['cspfqdn']
        token = vra8Conn['cspToken']

    threads = []
    with ThreadPoolExecutor(max_workers=20) as executor:
            for thisOwner in allOwners:
                threads.append(executor.submit(processUserforCacheBuilder, hostname, thisOwner, org, token, target, allowOrgOwner))

            for task in as_completed(threads):
                thisRes = task.result()
                for owner in thisRes:
                    verifiedUsersCache [owner] = thisRes[owner]

    #for thisOwner in allOwners:
    #    thisRes = processUserforCacheBuilder(hostname, thisOwner, org, token, target)
    #    for owner in thisRes:
    #        verifiedUsersCache[owner] = thisRes[owner]
        
    return verifiedUsersCache

def processGroupForCache(gpName, hostname, token, target, org):
    gpId = getGroupId(gpName, hostname, token, target, org)
    return {gpId:gpName, gpName:gpId}

def buildGroupCache(projectData, vra8Conn, token, org, target, projectName):
    groupCache = {}

    allGpNames = []
    for key in projectData:
        allGpNames = allGpNames + projectData[key]['groups']

    uniqueNamesSet = set(allGpNames)
    uniqGpNames = list(uniqueNamesSet)

    if target == 'onprem':
        hostname = vra8Conn['hostfqdn']
    else:
        hostname = vra8Conn['cspfqdn']
        token = vra8Conn['cspToken']

    threads = []
    with ThreadPoolExecutor(max_workers=20) as executor:
        for gpName in uniqGpNames:
            threads.append(executor.submit(processGroupForCache, gpName, hostname, token, target, org))

        for task in as_completed(threads):
            thisRes = task.result()
            for key in thisRes:
                groupCache[key] = thisRes[key]

    return groupCache
    
def checkvRAUser(user, projectGroups, projectName, verifiedUsersCache, groupCache, hostname, token, org, target='onprem'):

    headers = {'Authorization': '%s' % (token)}

    reqUrl = const.vra8_user_search % (hostname, user, org)

    logger.debug('Request URL: %s' % (reqUrl))
    #print('Request URL: %s' % (reqUrl))

    vraClient = RESTClient()
    resp = vraClient.get(reqUrl, headers=headers)

    if resp.status_code == 200:
        data = resp.json()
        logger.debug(data)

        user = data['user']['acct']

        if target == 'cloud':
            cloudGroups = getCloudGroupsforUser(hostname, token, org, user)
            data['user']['groups'] = cloudGroups

        validUser, verifiedUsersCache, groupCache = checkUserGroupMembership (hostname, token, verifiedUsersCache, projectGroups, projectName, data, user, groupCache, target, org)

        username = user

    elif resp.status_code == 404 and '@' in user:
        logger.warning('Unable to find user: %s' % (user))
        logger.warning('Going to try and find user without Domain suffix')

        shortUser = user.split('@')[0]

        validUser, verifiedUsersCache, groupCache, username = checkvRAUser(shortUser, projectGroups, projectName, verifiedUsersCache, groupCache, hostname, token, org, target)

        username = shortUser

    elif resp.status_code == 404:
        logger.warning('Unable to find user: %s' % (user))
        logger.warning('User %s is not a valid vRA 8 user, please check if user is configured in VIDM' % (user))
        print('\x1b[1;37;41m' + '!!! WARNING !!!' + '\x1b[0m')
        print('Unable to find user: %s' % (user))
        logger.error(resp.text)
        validUser = False
        username = None

    else:
        logger.error('Unable to get user data for: %s' % (user))
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)
        validUser = False
        username = None

    return validUser, verifiedUsersCache, groupCache, username


def verifyUsers(database, projectData, vra8Conn, token, target, projectName=None, allowOrgOwner=False, includeSecurityGroups=False):
    
    org = getLoggedInOrg(vra8Conn, token, target)
    if not org:
        logger.error('Unable to get org. PLease review the logs')
        System.exit(1)

    verifiedUsersCache = buildUserCache(database, projectData, vra8Conn, token, org, target, projectName, allowOrgOwner, includeSecurityGroups)
    #print(verifiedUsersCache)
    print("The size of the user cache is %s bytes" % (sys.getsizeof(verifiedUsersCache)))
    logger.debug("The size of the user cache is %s bytes" % (sys.getsizeof(verifiedUsersCache)))
    logger.debug(verifiedUsersCache)

    groupCache = buildGroupCache(projectData, vra8Conn, token, org, target, projectName)
    #print(groupCache)
    print("The size of the group cache is %s bytes" % (sys.getsizeof(groupCache)))
    logger.debug("The size of the group cache is %s bytes" % (sys.getsizeof(groupCache)))

    conn = createConnection(database)
    cur = conn.cursor()

    if projectName:
        if includeSecurityGroups:
            sql = '''SELECT newOwner, project from machinedata where project = '%s' and newOwner is not NULL
                     UNION
                    SELECT newOwner, project from networkresourcedata where project = '%s' and newOwner is not NULL;''' % (projectName, projectName)
        else:
            sql = '''SELECT newOwner, project from machinedata where project = '%s' and newOwner is not NULL;''' % (projectName)
    else:
        if includeSecurityGroups:
            sql = 'SELECT newOwner, project from machinedata where newOwner is not NULL UNION SELECT newOwner, project from networkresourcedata where newOwner is not NULL ;'
        else:
            sql = 'SELECT newOwner, project from machinedata where newOwner is not NULL;'

    cur.execute(sql)
 
    verifiedUsers = []
    updateDataset = []
    invalidUsers = {}

    for resp in cur:
        if not projectData.get(resp[1], None):
            print ('Project %s does not exist. Skipping user %s project check' % (resp[1],resp[0]))
            invalidUsers[resp[0]] = {'user': resp[0], 'project': resp[1]}
            logger.debug('Project %s does not exist. Skipping user %s project check' % (resp[1],resp[0]))
            continue

        if '@' in resp[0]:
            shortUser = resp[0].split('@')[0]
        else:
            shortUser = resp[0]

        thisProjectData = projectData[resp[1]]
        projectName = thisProjectData['name']

        logger.debug(thisProjectData)
        logger.debug(projectName)

        isOrgOwner = False
        if allowOrgOwner:
            #print(verifiedUsersCache.get(resp[0], 'NOGO'))
            if verifiedUsersCache.get(resp[0], None):
                isOrgOwner = verifiedUsersCache[resp[0]]['orgOwner']
            elif verifiedUsersCache.get(shortUser, None):
                isOrgOwner = verifiedUsersCache[shortUser]['orgOwner']

        if resp[0] in thisProjectData['users']:
        #if resp[0].lower() in [item.lower() for item in thisProjectData['users']]:    
            print('User %s is configured on project %s so assume user is valid' % (resp[0], projectName))
            logger.debug('User %s is configured on project %s so assume user is valid' % (resp[0], projectName))
            verifiedUsers.append(resp[0])
            validUser = True

        elif shortUser in thisProjectData['users']:
        #elif shortUser.lower() in [item.lower() for item in thisProjectData['users']]:  
            print('User %s is configured on project %s so assume user is valid' % (shortUser, projectName))
            logger.debug('User %s is configured on project %s so assume user is valid' % (shortUser, projectName))
            verifiedUsers.append(shortUser)
            if shortUser != resp[0]:
                updateDataset.append((shortUser, resp[0]))
            validUser = True

        elif isOrgOwner:
            if verifiedUsersCache.get(resp[0], None):
                print('User %s is an org owner so assume user is valid' % (resp[0]))
                logger.debug('User %s is an org owner so assume user is valid' % (resp[0]))
                verifiedUsers.append(resp[0])
                validUser = True
            elif verifiedUsersCache.get(shortUser, None):
                print('User %s is an org owner so assume user is valid' % (shortUser))
                logger.debug('User %s is an org owner so assume user is valid' % (shortUser))
                verifiedUsers.append(shortUser)
                if shortUser != resp[0]:
                    updateDataset.append((shortUser, resp[0]))
                validUser = True

        else:
            print('User %s is not configured directly on project %s, checking group membership.' % (shortUser, projectName))
            logger.debug('User %s is not configured directly on project %s, checking group membership.' % (shortUser, projectName))
            if not org:
                org = getLoggedInOrg(vra8Conn, token, target)
                if not org:
                    logger.error('Unable to get org. PLease review the logs')
                    System.exit(1)

            if target == 'onprem':
                hostname = vra8Conn['hostfqdn']
            else:
                hostname = vra8Conn['cspfqdn']
                token = vra8Conn['cspToken']

            if (verifiedUsersCache.get(resp[0], None) or verifiedUsersCache.get(shortUser, None)) and len(thisProjectData['groups']) > 0 :

                #this is a look up on project name in group and project name in user / other api call.
                #they need to match
                logger.debug('User CACHE HIT! %s %s' % (resp[0], shortUser))
                for thisGpName in thisProjectData['groups']:
                    if groupCache.get(thisGpName, None):
                        logger.debug('Group Cache HIT for group %s' %(thisGpName))
                        thisGpId = groupCache.get(thisGpName)
                        thisUser = verifiedUsersCache.get(resp[0], None)
                        if not thisUser:
                            username = shortUser
                        else:
                            username = resp[0]

                        if thisGpId in verifiedUsersCache[username]['groups']:
                            logger.debug('Found %s with ID: %s in group cache list below' % (thisGpName, thisGpId))
                            logger.debug(verifiedUsersCache[username]['groups'])
                            #need to check if this is a fix fo user mismnatch
                            if username != resp[0]:
                                updateDataset.append((username, resp[0]))
                                
                            validUser = True
                            break
                        else:
                            logger.debug('Unable to find %s with ID: %s in group cache list below' % (thisGpName, thisGpId))
                            logger.debug(verifiedUsersCache[username]['groups'])
                            validUser = False

                    else:
                        logger.debug('NO Group Cache HIT for %s' % (thisGpName))
                        validUser, verifiedUsersCache, groupCache,username = checkvRAUser(resp[0], thisProjectData['groups'], projectName, verifiedUsersCache, groupCache,  hostname, token, org, target)
                        if validUser and username != resp[0]:
                            updateDataset.append((username, resp[0]))
            else:
                validUser, verifiedUsersCache, groupCache, username = checkvRAUser(resp[0], thisProjectData['groups'], projectName, verifiedUsersCache, groupCache,  hostname, token, org, target)
                if validUser and username != resp[0]:
                    updateDataset.append((username, resp[0]))

            print ('Validation check result for %s: %s' % (resp[0], validUser))
            logger.debug('Validation check result for %s: %s' % (resp[0], validUser))

            if validUser:
                verifiedUsers.append(username)
            else:
                invalidUsers[resp[0]] = {'user': resp[0], 'project': resp[1]}
                logger.warning('Not a valid user or user/project combination that is configured in vRA 8. Please review configuration and csv file')
    conn.close()

    logger.debug('Cahce DUMP')
    logger.debug(verifiedUsersCache)
    logger.debug(groupCache)

    updateOwnerData(updateDataset, database)

    if len(invalidUsers.keys()) == 0:
        return True , invalidUsers, list(set(verifiedUsers))
    else:
        return False, invalidUsers, list(set(verifiedUsers))

    return None

def getAllvRA8CloudAccounts(hostname, token, supportedTypes=['vsphere', 'vcf']):
    headers = {'Authorization': '%s' % (token)}

    #need to remove the select to allow for vcf endpoints as they have additional IDs
    #reqUrl = '%s?$top=%s&$skip=%s&$select=cloudAccountType,id,cloudAccountProperties,name' % (const.vra8_get_all_cloud_accounts % (hostname), 500, 0)
    reqUrl = '%s?$top=%s&$skip=%s' % (const.vra8_get_all_cloud_accounts % (hostname), 200, 0)

    logger.debug('Request URL: %s' % (reqUrl))
    #print('Request URL: %s' % (reqUrl))

    vraClient = RESTClient()
    resp = vraClient.get(reqUrl, headers=headers)

    cloudAccounts = []
    if resp.status_code == 200:
        data = resp.json()
        logger.debug(data)
        #print(data)
        for acc in data['content']:
            if acc['cloudAccountType'] in supportedTypes:
                thisCloudAccount = {}
                thisCloudAccount['name'] = acc['name']
                if acc['cloudAccountType'] == 'vsphere':
                    thisCloudAccount['id'] = acc['id']
                elif acc['cloudAccountType'] == 'vmc':
                    if len(acc['enabledRegions']) > 0:
                        thisCloudAccount['id'] = acc['enabledRegions'][0]['cloudAccountId']
                    else:
                        thisCloudAccount['id'] = acc['id']
                elif acc['cloudAccountType'] == 'vcf':
                    resourceUrl = acc['customProperties']['vsphere']
                    urlSplit = resourceUrl.split('/')
                    thisCloudAccount['id'] = urlSplit[-1]
                elif acc['cloudAccountType'] == 'aws':
                    thisCloudAccount['id'] = acc['id']
                    thisCloudAccount['fqdn'] = 'AWS:%s' % acc['cloudAccountProperties']['accountId']
                elif acc['cloudAccountType'] in ['nsxt', 'nsxv']:
                    thisCloudAccount['id'] = acc['id']
                    associatedCloudAccountIds = []
                    associatedLinks = acc.get('_links',{}).get("associated-cloud-accounts", {'hrefs':[]}).get('hrefs', [])
                    for thisLink in associatedLinks:
                        urlList = thisLink.split('/')
                        associatedCloudAccountIds.append(urlList[-1])

                    thisCloudAccount['associatedCloudAccountIds'] = associatedCloudAccountIds


                thisCloudAccount['type'] = acc['cloudAccountType']

                if acc['cloudAccountType'] != 'aws':
                    thisCloudAccount['fqdn'] = acc['cloudAccountProperties']['hostName']
                cloudAccounts.append(thisCloudAccount)
    else:
        logger.error('Unable to get cloud account data ')
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)

    return cloudAccounts

def endpointLookup(database, hostname, token, project=None, supportedTypes=['vsphere', 'vcf'], includeSecurityGroups=False):

    conn = createConnection(database)
    cur = conn.cursor()
    if project:
        sql = '''SELECT distinct endpointFQDN from machinedata where project = '%s';''' % (project)
    else:
        sql = 'SELECT distinct endpointFQDN from machinedata;'

    #print(sql)
    logger.debug(sql)
    cur.execute(sql)

    allFqdn = cur.fetchall()

    if includeSecurityGroups:
        if project:
            sql = '''SELECT distinct endpointFQDN from networkresourcedata where project = '%s';''' % (project)
        else:
            sql = 'SELECT distinct endpointFQDN from networkresourcedata;'

        #print(sql)
        logger.debug(sql)
        cur.execute(sql)

        allNETFqdn = cur.fetchall()

    conn.close()

    logger.debug('ALL supplied endpoint FQDN')
    logger.debug(allFqdn)

    allCloudAccounts = getAllvRA8CloudAccounts(hostname, token, supportedTypes)
    logger.debug('All vRA 8 Cloud Accounts')
    logger.debug(allCloudAccounts)

    updateDataset = []
    validEndpoints = []
    missmatchEndpoints = []
    for thisFqdn in allFqdn:
        foundMatch = False
        for thisAcc in allCloudAccounts:
            if thisFqdn[0].lower() ==  thisAcc['fqdn'].lower():
                foundMatch = True
                updateDataset.append((thisAcc['id'], thisFqdn[0]))
                validEndpoints.append((thisAcc['id'], thisFqdn[0], thisAcc['name']))
                break
        if not foundMatch:
            missmatchEndpoints.append(thisFqdn[0])
            logger.error('Unable to find macthing vRA 8 Cloud Account for FQDN: %s Please check supplied csv file is correct' % (thisFqdn[0]))
            print('Unable to find macthing vRA 8 Cloud Account for FQDN: %s Please check supplied csv file is correct' % (thisFqdn[0]))

    updateEndpointData(updateDataset, database)

    if includeSecurityGroups:

        allNSXCloudAccounts = getAllvRA8CloudAccounts(hostname, token, ['nsxv', 'nsxt'])
        logger.debug('All vRA 8 NSX Cloud Accounts')
        logger.debug(allNSXCloudAccounts)

        updateNSXDataset = []
        
        for thisFqdn in allNETFqdn:
            foundMatch = False
            for thisAcc in allNSXCloudAccounts:
                if thisFqdn[0].lower() ==  thisAcc['fqdn'].lower():
                    foundMatch = True
                    if len(thisAcc.get('associatedCloudAccountIds', [])) > 0:
                        updateNSXDataset.append((thisAcc['associatedCloudAccountIds'][0], thisFqdn[0]))
                        validEndpoints.append(('%s|%s' % (thisAcc['id'], thisAcc['associatedCloudAccountIds'][0]), thisFqdn[0], thisAcc['name']))
                    else:
                        print('Unable to find associtated cloud account for NSX cloud account %s' % thisFqdn[0])
                        logger.error('Unable to find associtated cloud account for NSX cloud account %s' % thisFqdn[0])
                        missmatchEndpoints.append(thisFqdn[0])
                    break
            if not foundMatch:
                missmatchEndpoints.append(thisFqdn[0])
                logger.error('Unable to find macthing vRA 8 NSX Cloud Account for FQDN: %s Please check supplied csv file is correct' % (thisFqdn[0]))
                print('Unable to find macthing vRA 8 NSX Cloud Account for FQDN: %s Please check supplied csv file is correct' % (thisFqdn[0]))

        updateNSXEndpointData(updateNSXDataset, database)

    if len(missmatchEndpoints) == 0:
        return True, validEndpoints, missmatchEndpoints
    else:
        return False, validEndpoints, missmatchEndpoints

def updateVMData(updateDataset, database):

    conn = createConnection(database)
    sql = ''' UPDATE machinedata set vra8MachineId = ?, osType = ? where machineName = ?;
    '''

    logger.debug('Updating db with vRA 8 VM IDs')

    cur = conn.cursor()
    ret = cur.executemany(sql, updateDataset)
    conn.commit()
    conn.close()

def updateNSXVMData(updateDataset, database):

    conn = createConnection(database)
    sql = ''' UPDATE networkresourcedata set vra8MachineId = ? where resourceName = ?;
    '''

    logger.debug('Updating db with vRA 8 NSX VM IDs')
    print('Updating db with vRA 8 NSX VM IDs')
    #print(sql)
    #print(updateDataset)

    cur = conn.cursor()
    ret = cur.executemany(sql, updateDataset)
    conn.commit()
    conn.close()

def vmCheck(database, cloudAccountData, processedEndpoints, hostname, token, project=None, includeSecurityGroups=False):

    #Maybe Get all the VMs and then check if there any missing for your project
    #only do it once per execution / cloudaccount
    #loop over discoverd cloud accounts
    #somehow check this only runs once per cloudaccount with some sort of cache
    #print(cloudAccountData)
    for cloudAccount in cloudAccountData:

        updateDataset = [] # list of dict
        updateNSXDataset = []

        top = 200
        skip = 0

        if '|' in cloudAccount[0]:
            caId = cloudAccount[0].split('|')[1]
        else:
            caId = cloudAccount[0]

        caName = cloudAccount[2]

        if caId in processedEndpoints:
            continue

        processedEndpoints.append(caId)

        headers = {'Authorization': '%s' % (token)}

        vraClient = RESTClient()

        allDone = False

        allvRA8Machines = []

        while not allDone:

            reqUrl = '%s&$top=%s&$skip=%s' % (const.vra8_get_all_unmanaged_machines_for_cloud_account % (hostname, caId), top, skip)
            #reqUrl = '%s?$top=%s&$skip=%s&sort=createdAt,DESC&resourceRefreshStrategy=ASYNC&resourceTypes=Cloud.vSphere.Machine&origin=DISCOVERED&cloudAccounts=%s' % (const.vra8_get_all_discovered_machines_for_cloud_account % (hostname), top, skip, caName)

            logger.debug('Request URL: %s' % (reqUrl))
            #print('Request URL: %s' % (reqUrl))

            resp = vraClient.get(reqUrl, headers=headers)

            if resp.status_code == 200:
                data = resp.json()
                print('IAAS API to identify VMs returned %s discoverd VMs for this Cloud Account' % data['numberOfElements'])
                logger.debug('IAAS API to identify VMs returned %s discoverd VMs for this Cloud Account' % data['numberOfElements'])
           
                #logger.debug(data)
                for thisVM in data['content']:
                    if thisVM.get('name', None):
                        vmDataStr = '%s:%s' % (thisVM['name'], thisVM['id'])
                        if thisVM.get('customProperties', None):
                        #if thisVM.get('properties', None):
                            custProp = thisVM.get('customProperties')
                            #custProp = thisVM.get('properties')
                            if custProp.get('osType', None):
                                vmDataStr = '%s:%s' % (vmDataStr, custProp['osType'])
                        allvRA8Machines.append(vmDataStr)
                    else:
                        logger.warning('Skipping VM')
                        logger.warning('No Name on VM: %s' % (thisVM))

            else:
                print('something went wrong')
                logger.error('Unable to get discovered resources')
                logger.error('REST RESPONSE CODE: %s' % resp.status_code)
                logger.error(resp.text)
                print('Unable to get discoverd resources')
                print('REST RESPONSE CODE: %s' % resp.status_code)
                print(resp.text)
                break

            skip = skip + top
            if data['numberOfElements'] < top:
                allDone = True

        #print(allvRA8Machines)
        #get all VMs for cloud account from db
        conn = createConnection(database)
        cur = conn.cursor()
        sql = ''' SELECT machineName from machinedata where endpointId = '%s';
        ''' % (caId)

        logger.debug(sql)
        cur.execute(sql)
     
        allVMsDB = cur.fetchall()

        if includeSecurityGroups:
            sql = ''' SELECT resourceName from networkresourcedata where endpointId = '%s' and resourceType = 'Infrastructure.Network.SecurityGroup.NSX';
            ''' % (caId)
   
            logger.debug(sql)
            #print(sql)
            cur.execute(sql)

            allSgDb = cur.fetchall()

            allVMsDB += allSgDb                 
            #print(allVMsDB)

        #cur.execute("SELECT machineName from machinedata where endpointId = '%s';" % caId)

        #logger.debug(sql)
        #cur.execute(sql)

        for resp in allVMsDB:
            thisRes = [i for i in allvRA8Machines if i.startswith('%s:' % resp[0])]
            logger.debug(thisRes)
            #print(thisRes)
            if len(thisRes) == 1:
                vmData = thisRes[0].split(':')
                osType = ''
                if len(vmData) == 3:
                    osType = vmData[2]

                #this might need to be compared at lowercase
                if resp[0] == vmData[0]:
                    updateDataset.append((vmData[1],osType,vmData[0]))
                    if includeSecurityGroups:
                        updateNSXDataset.append((vmData[1],vmData[0]))

                else:
                    print('\x1b[1;37;41m' + '!!! WARNING !!!' + '\x1b[0m')
                    print('WARNING: UNABLE TO FIND VM: %s' % resp[0])
                    print('WARNING: VM %s will be omitted for now' % resp[0])
                    print('WARNING: VM may no longer be in vCenter or VM is already onboarded into a vRA 8 project')
                    logger.warning('Unable to find VM %s. This VM will be omitted for now' % resp[0])

            elif len(thisRes) == 0:
                print('\x1b[1;37;41m' + '!!! WARNING !!!' + '\x1b[0m')
                print('WARNING: UNABLE TO FIND VM: %s, 0 machines with name found' % resp[0])
                print('WARNING: VM %s will be omitted for now' % resp[0])
                print('WARNING: VM may no longer be in vCenter or VM is already onboarded into a vRA 8 project')
                logger.warning('Unable to find VM %s. This VM will be omitted for now. 0 machines with name found' % resp[0])
            else:
                print('\x1b[1;37;41m' + '!!! WARNING !!!' + '\x1b[0m')
                print('WARNING: DUPLICATE VM NAME DETECTED, MORE VALIDATION REQUIRED')
                print('WARNING: VM %s will be omitted for now, Multiple machines with name found.' % resp[0])
                logger.warning('Duplicate VMs found for VM %s. This VM will be omitted for now. Multiple machines with name found.' % resp[0])
                logger.warning(thisRes)

        conn.close()
        updateVMData(updateDataset, database)
        updateNSXVMData(updateNSXDataset, database)
        

    #make this project specific
    conn = createConnection(database)
    cur = conn.cursor()

    if project:
        if includeSecurityGroups:
            cur.execute('''select machineName, newOwner,project,endpointFQDN,deploymentName from machineData where vra8MachineId is NULL and project = '%s'
                union
                select resourceName, newOwner,project,endpointFQDN,deploymentName from networkresourcedata where vra8MachineId is NULL and project = '%s';''' % (project, project))
        else:
            cur.execute("select machineName, newOwner,project,endpointFQDN,deploymentName from machineData where vra8MachineId is NULL and project = '%s';" % (project))
    else:
        if includeSecurityGroups:
            cur.execute('''select machineName, newOwner,project,endpointFQDN,deploymentName from machineData where vra8MachineId is NULL
                        union
                        select resourceName, newOwner,project,endpointFQDN,deploymentName from networkresourcedata where vra8MachineId is NULL;''')      
        else:
            cur.execute("select machineName, newOwner,project,endpointFQDN,deploymentName from machineData where vra8MachineId is NULL;")

    badList = '########################################################\n**** UNABLE TO IDENTIFY FOLLOWING MACHINES IN VRA 8 ****\nMachine Name, Owner, Project, Endpoint, Deployment Name\n'
    counter = 0
    badListName = []
    for resp in cur:
        counter = counter + 1
        badList = badList + '%s,%s,%s,%s,%s\n' %(resp[0],resp[1],resp[2],resp[3],resp[4])
        badListName.append(resp[0])

    conn.close()
    if counter > 0:
        #print(badList)
        print('VM Validation Failed')
        print('Unidentified VMs List: ')
        print(*badListName, sep =', ')
        return False, processedEndpoints
    else:
        print('All VMs Identified')
        print('VM Validation Passed')
        return True, processedEndpoints

def addMultipleUsersToProject (hostname, token, projectId, newOwners):
    """
    add one or more user to project
    """
    modifyList = []

    for user in newOwners:
        thisUser = {
            "email": user,
            "role": "member",
            "type": "user"
        }
        modifyList.append(thisUser)


    url = "https://{}/project-service/api/projects/{}/principals".format(hostname,projectId)
    payload = {
                "modify": modifyList,
                "remove": []
              }

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    response = requests.request("PATCH", url, data=json.dumps(payload), headers=headers, verify=False)
#    print (response.content)
    if response.status_code == 200:
        return True
    else:
        logger.debug(response.status_code)
        logger.debug(response.text)
        return None

def patchProjectUsers(database, project, projectId, usersList, hostname, token, validUsers):

    conn = createConnection(database)
    cur = conn.cursor()
    sql = '''SELECT distinct newOwner from machinedata where project = '%s' and newOwner is not NULL;''' % (project)

    #print(sql)
    cur.execute(sql)

    allOwnersDb = cur.fetchall()
    conn.close()

    allOwnersList = []
    addedOwners = []

    for item in allOwnersDb:
        allOwnersList.append(item[0])

    for thisOwner in allOwnersList:
        if thisOwner not in usersList:
            if thisOwner in validUsers:
                addedOwners.append(thisOwner)

    resp = addMultipleUsersToProject (hostname, token, projectId, addedOwners)

    if resp:
        print('Added the following users')
        print(addedOwners)
        return True, addedOwners
    else:
        return False, None

def buildDeploymentPayloadBulk (hostfqdn, token, planLink, allOnboardingData, project, database, propList, includeCustProp, convertProp):

    #WIP
    #select project, projectId, endpointId, deploymentName, machineName, machineId, vra8MachineId, newOwner as owner from machinedata where import = 'yes' and project = '%s' order by deploymentName desc

    allDeployments = {}
    currentDepName = ''
    for item in allOnboardingData:
        thisResourcesList = []
        print(item['deploymentName'])
        currentDepName = item['deploymentName']

        if not allDeployments.get(currentDepName, None):
            print('Setup for new deployment')
            allDeployments[currentDepName] = {
                        "planLink": planLink,
                        "name": currentDepName,
                        "owner": item['owner'],
                        "description": item['deploymentDescription'],
                        "resources": []
                        }

        else:
            print('Deployment already setup, will add resources')

        resprops = buildProperties (database, item['machineId'], propList, item['owner'], includeCustProp, convertProp)

        resourceLink = '/resources/compute/%s' % ( item['vra8MachineId'])

        thisResource = {
            #"ruleLinks": [ "/relocation/onboarding/rule/include"],
            "link": resourceLink,
            "name": item['machineName']
            #"customProperties": resprops,
            #"options": ["DISABLE_CUSTOM_PROPERTIES_INHERITANCE"]
        }
        allDeployments[currentDepName]['resources'].append(thisResource)

    allDeploymentsList = list(allDeployments.values())
    return allDeploymentsList


def createDeploymentBulk (hostfqdn, token, planLink, allOnboardingData, project, database, propList, includeCustProp, convertProp):
    """
    Create Deployment

    WIP
    """
    chunkSize = 200
    error = False

    deployments = buildDeploymentPayloadBulk (hostfqdn, token, planLink, allOnboardingData, project, database, propList, includeCustProp, convertProp)

    deploymentChunks = [deployments[i:i + chunkSize] for i in range(0, len(deployments), chunkSize)]

    for thisChunk in deploymentChunks:

        payload = {
            "planLink": planLink,
            "deployments": thisChunk
            }

        logger.debug(json.dumps(payload))
        reqUrl = "https://{}/relocation/onboarding/task/create-deployment-bulk".format(hostfqdn)

        headers = {
            'accept': "application/json",
            'content-type': "application/json",
            'Authorization': token
            }

        vraClient = RESTClient()

        logger.debug('Request URL: %s' % (reqUrl))
        #print('Request URL: %s' % (reqUrl))

        resp = vraClient.post(reqUrl, headers=headers, data=json.dumps(payload))

        if resp.status_code == 200:

            logger.debug('Submitted a bulk deployment update request successfully')
        else:
            logger.error('Unable to create bulk deployment')
            logger.error('REST RESPONSE CODE: %s' % resp.status_code)
            logger.error(resp.text)
            logger.error(json.dumps(payload))
            print(json.dumps(payload))
            print('Unable to create bulk deployment')
            print('REST RESPONSE CODE: %s' % resp.status_code)
            print(resp.text)

    if not error:
        return True
    else:
        return False

def updateResource(hostfqdn, token, planLink, resourceName, resourceLink, resprops):

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    vraClient = RESTClient()

    reqUrl = 'https://%s%s' % (hostfqdn, resourceLink)

    print(reqUrl)

    logger.debug('Request URL: %s' % (reqUrl))

    payload = {
          "ruleLinks": [
                "/relocation/onboarding/rule/include",
                "/relocation/onboarding/rule/managed"
                ],
          "diskLinks": [],
          "resourceName": resourceName,
          "customProperties": resprops,
          "options": [ "DISABLE_CUSTOM_PROPERTIES_INHERITANCE" ]
              }

    print(payload)
    resp = vraClient.patch(reqUrl, headers=headers, data=json.dumps(payload))

    if resp.status_code == 200:
        return True
    else:
        logger.error('Unable to update resource properties')
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)
        logger.error(json.dumps(payload))
        print(json.dumps(payload))
        print('Unable to update resource properties')
        print('REST RESPONSE CODE: %s' % resp.status_code)
        print(resp.text)
        return None

def getAllOnboardingResourceLinksPerPlan(hostfqdn, token, planLink, limit):
    #getAllResrouceInfo from /relocation/onboarding/resource?$expand=true&$limit=5000&$filter=planLink+eq+'/relocation/onboarding/plan/9c937d99-3564-4b98-a560-d0eeff6e00b1'&$select=resourceLink,resourceName
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    vraClient = RESTClient()

    reqUrl = "https://%s/relocation/onboarding/resource?$expand=true&$limit=%s&$filter=planLink+eq+'%s'&$select=documentSelfLink,resourceName" % (hostfqdn, limit, planLink)

    logger.debug('Request URL: %s' % (reqUrl))

    resp = vraClient.get(reqUrl, headers=headers)

    allResourceLinks = {}
    if resp.status_code == 200:
        data = resp.json()

        #need to implement paging here
        #need to check for a nextPageLink and follow that untill it not there

        logger.debug(data)

        for thisItem in data['documents']:
            logger.debug(thisItem)
            allResourceLinks[data['documents'][thisItem]['resourceName']] = data['documents'][thisItem]['documentSelfLink']

        return allResourceLinks

    else:
        logger.error('Unable to update resource properties')
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)
        logger.error(json.dumps(payload))
        print(json.dumps(payload))
        print('Unable to update resource properties')
        print('REST RESPONSE CODE: %s' % resp.status_code)
        print(resp.text)
        return None

def checkFileExists(filename):
    return os.path.isfile(filename)

def updateNewPropName(database, updateDataset):

    #Need to fix validation here to check the db was updated.
    result = False
    conn = createConnection(database)

    sql = ''' UPDATE machineproperties set newPropertyName = ? where propertyName = ?;
    '''

    logger.debug('Updating db with new property names')
    cur = conn.cursor()
    ret = cur.executemany(sql, updateDataset)
    conn.commit()
    conn.close()
    result = True

    return result

def removeDeletedProps(database, keepDataset):

    conn = createConnection(database)

    keepStr = "','".join(keepDataset)
    sql = ''' DELETE from machineproperties where propertyName not in ('%s');
    ''' % keepStr

    logger.debug('Removing Custom Properties from db')
    logger.debug(sql)

    cur = conn.cursor()
    ret = cur.execute(sql)
    conn.commit()
    conn.close()

    return True

def fillPropName(database):
    result = False
    conn = createConnection(database)

    sql = ''' UPDATE machineproperties set newPropertyName = propertyName where newPropertyName IS NULL;
    '''

    logger.debug('Filling Property Names in DB')
    cur = conn.cursor()
    ret = cur.execute(sql)
    conn.commit()
    conn.close()
    result = True

    return result

def validateCustomPropertiesCSV(filename, database):
    #assume that include custom properies is true, needs to be checked before calling function

    propFileName = filename.replace('.', '_custom_properties.')
    checkDBExists = checkFileExists(propFileName)

    if checkDBExists:
        print ('File %s located' % (propFileName))
        logger.info('File %s located' % (propFileName))
    else:
        print('\x1b[1;37;41m' + '!!! ERROR !!!' + '\x1b[0m')
        print ('Unable to locate file %s.' % (propFileName))
        logger.error('Unable to locate file %s.' % (propFileName))
        return None

    reader = csv.DictReader(open(propFileName))

    updateDataset = []
    keepDataset = []

    for row in reader:
        if not row['propertyName'] or row['propertyName'] == '':
            continue
        else:
            keepDataset.append(row['propertyName'])

        if not row['newPropertyName'] or row['newPropertyName'] == '':
            continue
        elif row['propertyName']:
            newPropNameNoSpaces = row['newPropertyName'].replace(' ', '')
            logger.debug('Updating new prop name in db %s - %s' % (newPropNameNoSpaces, row['propertyName']) )
            updateDataset.append((newPropNameNoSpaces, row['propertyName']))

    resultUpdate = updateNewPropName(database, updateDataset)
    resultRemove = removeDeletedProps(database, keepDataset)
    resultFillData = fillPropName(database)

    if resultUpdate and resultRemove and resultFillData:
        return True
    else:
        return False

def storeMemberChanges(database, project, projectId, addedMembers):

    try:
        conn = createConnection(database)
        c = conn.cursor()
        sqlCreate = """ CREATE TABLE IF NOT EXISTS membershipchanges (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        projectId text,
        project text,
        member text
        );
        """
        c.execute(sqlCreate)
        conn.commit()
    except Exception as e:
        print(e)
        return False

    insertData = []
    for member in addedMembers:
        insertData.append((projectId, project, member))

    sql = ''' INSERT INTO membershipchanges(projectId, project, member)
                VALUES (?,?,?);'''

    logger.debug(sql)
    logger.debug(insertData)

    cur = conn.cursor()
    ret = cur.executemany(sql, insertData)
    conn.commit()
    conn.close()
    #Need to check c.rowcount to see if it the same as len(insertData)
    #return False if it not

    return True

def revertProjectMemberChanges(hostfqdn, token, database, project):
    print ('Processing project: %s' % (project))

    conn = createConnection(database)
    conn.row_factory = lambda cursor, row: row[0]
    cur = conn.cursor()

    sql = '''SELECT distinct member from membershipchanges where project = '%s';''' % (project)

    logger.debug(sql)
    #print(sql)
    cur.execute(sql)

    allMembers = cur.fetchall()

    sql = '''SELECT projectId from membershipchanges where project = '%s' limit 1;''' % (project)

    logger.debug(sql)
    #print(sql)

    cur.execute(sql)

    allIds = cur.fetchall()
    #print(allIds)
    if len(allIds) > 0:
        projectId = allIds[0]
    else:
        print('Nothing to revert')
        return True

    print (allMembers)
    print (projectId)

    updateProject = removeUserfromProject (hostfqdn, token, projectId, allMembers)

    if updateProject:
        sql = '''DELETE from membershipchanges where projectId = '%s';''' % (projectId)

        cur.execute(sql)

        conn.commit()

    conn.close()

    return updateProject

def addBlueprintRef(hostname, token, planLink, deploymentLink, bpId=None, autoGenerate=False ):
    #this is to address error in ui relating to autoGenerate entry
    #possible to expand this later to do full blueprint association

    headers = {'Authorization': '%s' % (token)}

    reqUrl = const.vra8_add_blueprint_ref % (hostname)

    logger.debug('Request URL: %s' % (reqUrl))
    #print('Request URL: %s' % (reqUrl))

    payload = {
               "planLink": planLink,
               "autoGenerate": autoGenerate,
               "deploymentLink": deploymentLink,
               "name": "auto-generated-PVE"
    }

    if bpId:
        payload['templateLink'] = '/blueprint/api/blueprints/%s' % (bpId)

    logger.debug(json.dumps(payload))

    vraClient = RESTClient()
    resp = vraClient.post(reqUrl, data=json.dumps(payload), headers=headers)

    if resp.status_code == 200:
        logger.debug('Blueprint ref created for %s' % (deploymentLink))
        return True
    else:
        logger.error('Unable to add blueprint ref')
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)
        return False

def deleteOnboardingDeployment(hostname, token, deploymentLink):

    headers = {'Authorization': '%s' % (token)}

    reqUrl = "https://%s%s" % (hostname, deploymentLink)

    vraClient = RESTClient()

    resp = vraClient.delete(reqUrl, headers=headers)
   
    if resp.status_code == 200:
        logger.debug('Onboarding Deployment Removed From Onboarding Plan %s' % (deploymentLink))
        return True
    else:
        logger.error('Unable to remove onboarding deployment')
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)
        return False

def extractCloudTemplateComponentName(cloudTemplate, resourceNumber=0, resourceTypes=['Cloud.vSphere.Machine','Cloud.Machine','Cloud.AWS.EC2.Instance']):

    allMachines = []
    data = yaml.load(cloudTemplate, Loader=SafeLoader)
    if data:
        print('Number of resources in cloud template %s' % len(data.get('resources',[])))
        logger.debug('Number of resources in cloud template %s' % len(data('resources',[])))

        for resource in data('resources',[]):
            print(data['resources'][resource]['type'])
            if data['resources'][resource]['type'] in resourceTypes:
                if data['resources'][resource]['properties'].get('count', None):
                    allMachines.append('%s[0]' % (resource))
                else:
                    allMachines.append(resource)
    
    if len(allMachines) > resourceNumber:
        logger.debug('Returning Component Name:  %s' % (allMachines[resourceNumber]))
        print('Returning Component Name:  %s' % (allMachines[resourceNumber]))
        return allMachines[resourceNumber]
    else:
        return ''

def extractCloudTemplateData(cloudTemplate, resourceTypes=['Cloud.vSphere.Machine','Cloud.Machine', 'Cloud.AWS.EC2.Instance']):

    allData = {}
    data = yaml.load(cloudTemplate, Loader=SafeLoader)
    if data:
        print('Number of resources in cloud template %s' % len(data.get('resources',[])))
        logger.debug('Number of resources in cloud template %s' % len(data.get('resources', [])))
    
        resourceNumber = 0

        for resource in data.get('resources', []):
            if data['resources'][resource]['type'] in resourceTypes:
                print(data['resources'][resource]['type'])
                print(resource)
                allData[resourceNumber] = data['resources'][resource]
                allData[resourceNumber]['componentName'] = resource
                resourceNumber = resourceNumber + 1

    else:
        print('No Yaml Data returned')
        logger.warning('No Yaml Data returned')

    return allData

def extractCloudTemplateResourceName(cloudTemplate, supportedTypes=['type: Cloud.vSphere.Machine', 'type: Cloud.Machine', 'type: Cloud.AWS.EC2.Instance']):

    split1 = cloudTemplate.split('resources:');
    allResources = split1[1];
    pipedResources = allResources.replace('\n',"|");

    regex = r"\|\s{2}\S| *:\|"
    matches = re.finditer(regex, pipedResources)

    for matchNum, match in enumerate(matches, start=1):
        logger.debug (match.group())
        thisMatch = match.group()
        thisReplace = match.group().replace('|  ','|:|')
        updatedStr = pipedResources.replace(thisMatch, thisReplace)
        pipedResources = updatedStr

    logger.debug(pipedResources)

    splitResourceName = pipedResources.split('|:|');

    for thisResource in splitResourceName:
        if thisResource == '':
            continue

        if any(thisType in thisResource for thisType in supportedTypes):
           print('Not a supported type, supported types %s' % supportedTypes)
           continue

        logger.debug(thisResource)
        
        regex2 = r"^.*?:\|"
        thisComponentName = re.finditer(regex2, thisResource)

        allMatches = []
        for matchNum, match in enumerate(thisComponentName, start=1):
            allMatches.append(match.group())

        if len(allMatches) == 0:
            print ('got balnk')
            return ''
    
        thisName = allMatches[0].replace(':|','')
    
        if '    count:' in thisResource:
            thisName = thisName + '[0]'
    
        print ('Component Name: ' + thisName)
        logger.debug('Component Name: ' + thisName)
        return thisName

    return ''

def getVersionvRA(hostname, vtype='MAJOR'):    
    #type can be ALL|MAJOR

    reqUrl = const.vra8_version % (hostname)
    logger.debug('Request URL: %s' % (reqUrl))

    vraClient = RESTClient()
    resp = vraClient.get(reqUrl)
    if resp.status_code == 200:
        data = resp.json()

        logger.debug(data)
        version = str(base64.b64decode(data["applicationVersion"]), "utf-8")

        version = version.replace('VMware ', '')

        if vtype == 'ALL':
            return version.replace('\\n', '').strip()
            
        elif vtype == 'MAJOR':
            versionData = version.split(' ')
            versionNumber = versionData[2]
            majorTmp = versionNumber.split('.')
            majorNumber = '%s.%s' % (majorTmp[0],majorTmp[1])
            return majorNumber

        elif vtype == 'MAJOR_PLUS':
            versionData = version.split(' ')
            versionNumber = versionData[2]
            majorTmp = versionNumber.split('.')
            majorNumberPlus = '%s.%s.%s' % (majorTmp[0],majorTmp[1],majorTmp[2])
        
            return majorNumberPlus
    else:
        logger.error('Unable to get vRA version')
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)
        return None

def getCloudTemplateYaml(ctId, hostname, token):

    headers = {'Authorization': '%s' % (token)}
    
    cloudTemplateStr = ''

    reqUrl = const.vra8_get_cloud_template % (hostname, ctId)
    logger.debug('Request URL: %s' % (reqUrl))
  
    vraClient = RESTClient()
    resp = vraClient.get(reqUrl, headers=headers)
    if resp.status_code == 200:
        data = resp.json()
        cloudTemplateStr = data['content']

    else:
        logger.error('Unable to get cloud template yaml')
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)

    return cloudTemplateStr

def getAllCloudTemplates(hostname, token, top=200):

    headers = {'Authorization': '%s' % (token)}

    skip = 0
    totalElements = top * 3

    allCloudTemplateDict = {}

    vraClient = RESTClient()
    
    while skip < totalElements:
        reqUrl = const.vra8_get_all_cloudTemplates % (hostname, skip, top)
        logger.debug('Request URL: %s' % (reqUrl))
        print(reqUrl)
        resp = vraClient.get(reqUrl, headers=headers)

        if resp.status_code == 200:
            data = resp.json()
            #use paging from gerAllSecurityGroups

            for thisItem in data['content']:
                #name collision here, needs to be reworked to be unique list
                #ctName:|:project name to be used
                ctName = thisItem['name']
                ctProject = thisItem['projectName']
                allCloudTemplateDict['%s:|:%s' % (ctName, ctProject)] = thisItem

        else:
            logger.error('Unable to get cloud templates')
            logger.error('REST RESPONSE CODE: %s' % resp.status_code)
            logger.error(resp.text)
            return None
    
        totalElements = data['totalElements']
        skip = skip + top

    return allCloudTemplateDict

def updateCloudTemplateNames(database, updateDataset):

    #Need to fix validation here to check the db was updated.
    result = False
    conn = createConnection(database)

    sql = ''' UPDATE machinedata set cloudTemplateName = ? where osType = ? and cloudTemplateName = '';
    '''

    logger.debug(updateDataset)
    logger.debug('Updating db with default cloud template names')
    cur = conn.cursor()
    ret = cur.executemany(sql, updateDataset)
    logger.debug(updateDataset)
    conn.commit()
    conn.close()
    result = True

    return result

def updateCloudTemplateIds(database, updateDataset, include=True):

    result = False
    conn = createConnection(database)

    logger.debug('Updating db with cloud template ids')
    logger.debug(updateDataset)
    print(updateDataset)

    #conn.set_trace_callback(print)
    cur = conn.cursor()
    
    if include:
        sql = ''' UPDATE machinedata set cloudTemplateId = ? where cloudTemplateName like ? and project in (?);
        '''
        ret = cur.executemany(sql, updateDataset)
    else:
        for thisData in updateDataset:
            print(thisData)
            if len(thisData[2]) > 0:
                ret = cur.execute('UPDATE machinedata set cloudTemplateId = ? where cloudTemplateName like ? and project not in ({})'.format(','.join('?'*len(thisData[2]))), (thisData[0], thisData[1]) + tuple(thisData[2]))
            else:
                ret = cur.execute('UPDATE machinedata set cloudTemplateId = ? where cloudTemplateName like ?', (thisData[0], thisData[1])) 

    conn.commit()
    conn.close()
    result = True

    return result

def validateCloudTemplatesForAllProject(database, thisCT, projectList):

    result = True
    unavailableProjects = []
    sql = "SELECT distinct(project), cloudTemplateName from machinedata where project != '%s' and cloudTemplateName Like '%s:_';" % (thisCT['projectName'], thisCT['name'])

    logger.debug(sql)
    conn = createConnection(database)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    logger.debug(sql)
    cur.execute(sql)

    allProjectct = cur.fetchall()

    conn.close()

    logger.debug("Number of projects without access to CT: %s" % (len(allProjectct)))

    for thisEntry in allProjectct:
        if thisEntry[0] in projectList:
            print ( "Cloud Template %s is available in project %s." % (thisCT['name'], thisEntry[0]))
            logger.debug( "Cloud Template %s is available in project %s." % (thisCT['name'], thisEntry[0]))
        else:
            print ( "Cloud Template %s is not available in project %s." % (thisCT['name'], thisEntry[0]))
            logger.warning( "Cloud Template %s is not available in project %s." % (thisCT['name'], thisEntry[0]))
            unavailableProjects.append(thisEntry[0])
            result = False
    
    return result, unavailableProjects


def validateCloudTemplates(database, allCT, defaultLinuxCT, defaultWindowsCT, hostname, token, target='onprem'):
    validatedCT = False
    problemCT = []
    ctProjectMap = {}
    allCTUpd = []

    nameUpdateDataset = [('%s:0' % defaultLinuxCT, 'LINUX'),('%s:0' % defaultWindowsCT, 'WINDOWS')]

    updResNames = updateCloudTemplateNames(database, nameUpdateDataset)
    if not updResNames:
        logger.warning('unable to add cloudtemplate names to dataset')

    sql = "SELECT distinct cloudTemplateName, project from machinedata where cloudTemplateName != '';"

    conn = createConnection(database)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    logger.debug(sql)
    cur.execute(sql)

    allDBctTmp = cur.fetchall()
    allDBct = [dict(row) for row in allDBctTmp]

    logger.debug('Fetch All')
    logger.debug(allDBctTmp)
    conn.close()

    for thisCT in allDBct:
        ctProjectMap[thisCT['cloudTemplateName'].split(':')[0]] = ctProjectMap.get(thisCT['cloudTemplateName'].split(':')[0], []) + [thisCT['project']]

    logger.debug(ctProjectMap)
    print(ctProjectMap)

    for thisCT in allCT:
        ctName = thisCT.split(':')[0]
        ctProject = ctProjectMap.get(ctName, ['NO-PROJECT'])[0]
        allCTUpd.append('%s:|:%s' % (ctName, ctProject))

    for thisCT in allDBct:
        ctName = thisCT['cloudTemplateName'].split(':')[0]
        ctProject = thisCT['project']
        allCTUpd.append('%s:|:%s' % (ctName, ctProject))    

    #allCT = allCT + allDBct
    allCTSet = set(allCTUpd)
    allCTList = list(allCTSet) 
    #print(allCTList)
    logger.debug(allCTList)
    
    allCloudTemplates = getAllCloudTemplates(hostname, token)
    validCloudTemplates = {}
    updateDataset = []
    updateDatasetOrg = []
    projectCheckCTs = []
    problemList = []
    orgTemplates = {}

    if not allCloudTemplates:
        logger.error('Unable to get cloud templates')
        return validatedCT, allCT

    for key in allCTList:
        if key in allCloudTemplates.keys():
            if not allCloudTemplates[key]['requestScopeOrg']:
                #print(allCloudTemplates[key]['requestScopeOrg'])
                print('Need to check if CT %s is available in project %s' % (allCloudTemplates[key]['name'], key.split(':|:')[1]))
                logger.warning('Need to check if CT %s is available in project %s' % (allCloudTemplates[key]['name'], key.split(':|:')[1]))
                checkProjects, problemProjects = validateCloudTemplatesForAllProject(database, allCloudTemplates[key], ctProjectMap[key.split(':|:')[0]])
                if checkProjects:
                    validCloudTemplates[key] = allCloudTemplates[key]
                    updateDataset.append((allCloudTemplates[key]['id'], '%s:_' % key.split(':|:')[0], '%s' % key.split(':|:')[1]))
                else:
                    problemCT.append(key)
                    problemList.append('Cloud Template %s is not available in the following projects %s' % (key, ','.join(problemProjects)))
                    
            else:
                print('Cloud template %s is scoped for ORG' % allCloudTemplates[key]['name'])
                logger.warning('Cloud template %s is scoped for ORG' % allCloudTemplates[key]['name'])

                validCloudTemplates[key] = allCloudTemplates[key]
                thisProjectList = ctProjectMap[key.split(':|:')[0]].copy()
                thisProjectList.remove(key.split(':|:')[1])
                updateDatasetOrg.append((allCloudTemplates[key]['id'], '%s:_' % key.split(':|:')[0], thisProjectList))
                orgTemplates[key.split(':|:')[0]] = allCloudTemplates[key]['id']

        else:
            if 'NO-PROJECT' in key:
                print('Cloud Template %s is not currenlty set on any deployment' % (key))
                logger.warning('Cloud Template %s is not currently set on any deployment' % (key))

            else:
                if key.split(':|:')[0] in orgTemplates.keys():
                    thisProjectList = ctProjectMap[key.split(':|:')[0]].copy()
                    thisProjectList.remove(key.split(':|:')[1])
                    updateDatasetOrg.append((orgTemplates[key.split(':|:')[0]], '%s:_' % key.split(':|:')[0], thisProjectList))
                else:
                    matching_keys = [keycheck for keycheck in allCloudTemplates if keycheck.startswith(key.split(':|:')[0] )]
                    ctMatchFound = False
                    for thisKey in matching_keys:
                        if allCloudTemplates[thisKey]['requestScopeOrg']:
                            print('Cloud template %s is scoped for ORG' % allCloudTemplates[thisKey]['name'])
                            logger.warning('Cloud template %s is scoped for ORG' % allCloudTemplates[thisKey]['name'])

                            validCloudTemplates[key] = allCloudTemplates[thisKey]
                            thisProjectList = ctProjectMap[key.split(':|:')[0]].copy()
                            thisProjectList.remove(key.split(':|:')[1])
                            updateDatasetOrg.append((allCloudTemplates[thisKey]['id'], '%s:_' % key.split(':|:')[0], thisProjectList))
                            orgTemplates[key.split(':|:')[0]] = allCloudTemplates[thisKey]['id']
                            ctMatchFound = True
                            break

                    if not ctMatchFound:
                        problemCT.append(key)
                        problemList.append('Cloud Template %s is not available in any projects' % (key))

    if len(updateDatasetOrg) > 0:
        updResIds = updateCloudTemplateIds(database, updateDatasetOrg, False)
        if not updResIds:
            logger.warning('unable to add cloudtemplate ids to dataset')

    if len(updateDataset) > 0:
        updResIds = updateCloudTemplateIds(database, updateDataset)
        if not updResIds:
            logger.warning('unable to add cloudtemplate ids to dataset')

    if len(problemCT) == 0:
        validatedCT = True

    return validatedCT, problemCT, problemList


def getAllDeploymentLeaseData(dbFilename, project):
    conn = sqlite3.connect(dbFilename)

    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    logger.debug('DB filename: ' + dbFilename)

    sql = '''select deploymentName, leaseEnd, projectId from machinedata where project = '%s' order by deploymentName desc;''' % (project)

    logger.debug(sql)
    print(sql)

    c.execute(sql)

    res = c.fetchall()
    logger.debug(res)
    return res    

def getDeploymentByName (hostfqdn, token, deploymentName, projectId=None):
    """
    """

    vraClient = RESTClient()

    reqUrl = const.vra8_get_deployment_by_name % hostfqdn


    if projectId:
        filterUrl = '%s?$skip=0&$top=10&expand=lastRequest&name=%s&projects=%s' % (reqUrl, deploymentName, projectId)
    else:
        filterUrl = '%s?$skip=0&$top=10&expand=lastRequest&name=%s' % (reqUrl, deploymentName)

    logger.debug('Request URL: %s' % (filterUrl))
    print('Request URL: %s' % (filterUrl))

    
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    resp = vraClient.get(filterUrl, headers=headers )
    # print (response.content)
    if resp.status_code == 200:
        data = resp.json()
        logger.debug(data)
        if data['numberOfElements'] == 1:
            return data['content'][0]
        else:
            print('Unexpected Number of deployments returned from search : %s' % data['numberOfElements'] )
            return None
    else:
        return None

def getDeploymentActions(hostfqdn, token, deploymentId):
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    vraClient = RESTClient()

    reqUrl = const.vra8_get_deployment_actions % (hostfqdn, deploymentId)

    logger.debug('Request URL: %s' % (reqUrl))
    print('Request URL: %s' % (reqUrl))
    

    resp = vraClient.get(reqUrl, headers=headers )

    if resp.status_code == 200:
        data = resp.json()
        logger.debug(data)
        return data
    else:
        return None

def runDeploymentAction(hostfqdn, token, deploymentId, actionId, inputPayload):
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    logger.debug('Requesting day 2 action %s' % (actionId));

    vraClient = RESTClient()

    reqUrl = const.vra8_run_day2_action % (hostfqdn, deploymentId)

    payload = { "actionId": actionId, "targetId": deploymentId, "inputs": inputPayload}

    resp=vraClient.post(reqUrl, headers=headers, data=json.dumps(payload))
        
    if resp.status_code == 200:
        data = resp.json()
        logger.debug('Action request submitted')
        logger.debug(data)
        return data
    else:
        logger.error('Unable to submit day 2 request')
        logger.error('Response Code: %s' % resp.status_code )
        logger.error('Response: %s' % json.dumps(resp.json()) )
        print('Unable to submit day 2 request')
        print('Response Code: %s' % resp.status_code )
        print('Response: %s' % json.dumps(resp.json()) )
        return None

def getDeploymentActionStatus(hostfqdn, token, requestId):
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    logger.debug('Requesting day 2 action %s' % (requestId));

    vraClient = RESTClient()

    reqUrl = const.vra8_get_request_status  % (hostfqdn, requestId)

    resp=vraClient.get(reqUrl, headers=headers)
        
    if resp.status_code == 200:
        data = resp.json()
        logger.debug('Action request response')
        logger.debug(data)
        return data
    else:
        logger.error('Unable to get request status')
        logger.error('Response Code: %s' % resp.status_code )
        logger.error('Response: %s' % json.dumps(resp.json()) )
        print('Unable to get request status')
        print('Response Code: %s' % resp.status_code )
        print('Response: %s' % json.dumps(resp.json()) )
        return None

def getAllIntegrations(hostfqdn, token):
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
        }

    vraClient = RESTClient()

    reqUrl = const.vra8_get_all_integrations % (hostfqdn)
    print(reqUrl)

    resp = vraClient.get(reqUrl, headers=headers )

    if resp.status_code == 200:
        data = resp.json()
        logger.debug(data)
        return data['content']
    else:
        logger.error('Unable to get integrations')
        logger.error('Response Code: %s' % resp.status_code )
        logger.error('Response: %s' % json.dumps(resp.json()) )
        print('Unable to get integrations')
        print('Response Code: %s' % resp.status_code )
        print('Response: %s' % json.dumps(resp.json()) )
        return None

def getCTforProjects(database, project=None):
    allCTData = {}
    
    if project:
        sql = "SELECT distinct cloudTemplateId, cloudTemplateName from machinedata where project = '%s';" % project
    else:
        sql = "SELECT distinct cloudTemplateId, cloudTemplateName from machinedata;"

    conn = createConnection(database)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    logger.debug(sql)
    cur.execute(sql)

    allDBct = cur.fetchall()

    conn.close()

    for thisCT in allDBct:
        #print(thisCT['cloudTemplateName'])
        #print(thisCT['cloudTemplateId'])
        ctName = thisCT['cloudTemplateName'].split(':')[0]
        allCTData[thisCT['cloudTemplateId']] = ctName

    return allCTData

def iconCacheBuilder(hostfqdn, token, database, projects=None):

    allCTData = {}
    if projects:
        for project in projects:
            ctData = getCTforProjects(database, project=project)
            for ct in ctData:
                allCTData[ct['cloudTemplateId']] = ct['cloudTemplateName']
    else:
        allCTData = getCTforProjects(database)

    iconCache = {}

    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
    }

    vraClient = RESTClient()

    for thisCTId in allCTData.keys():
        reqUrl = const.vra8_search_catalog_item_by_name % (hostfqdn, allCTData[thisCTId])
        print(reqUrl)

        resp = vraClient.get(reqUrl, headers=headers )

        if resp.status_code == 200:
            data = resp.json()
            logger.debug(data)
            for thisResp in data['content']:
                reqUrl = const.vra8_get_catalog_item_by_id % (hostfqdn, thisResp['id'])
                print(reqUrl)

                resp = vraClient.get(reqUrl, headers=headers )
                if resp.status_code == 200:
                    data = resp.json()
                    logger.debug(data)
                    externalId = data['externalId'].replace('/blueprint/api/blueprints/', '')
                    if externalId == thisCTId:
                        iconCache[thisCTId] = data['iconId']
                    else:
                        logger.warning('CT to Catlog external ID mismatch, wrong catalog item found.')
                else:
                    logger.error('Unable to get integrations')
                    logger.error('Response Code: %s' % resp.status_code )
                    logger.error('Response: %s' % json.dumps(resp.json()) )
                    print('Unable to get integrations')
                    print('Response Code: %s' % resp.status_code )
                    print('Response: %s' % json.dumps(resp.json()) )

        else:
            logger.error('Unable to get integrations')
            logger.error('Response Code: %s' % resp.status_code )
            logger.error('Response: %s' % json.dumps(resp.json()) )
            print('Unable to get integrations')
            print('Response Code: %s' % resp.status_code )
            print('Response: %s' % json.dumps(resp.json()) )
            

    return iconCache

def getDeploymentDataForLookup(database, projects=None):
    allDeploymentData = {}
    
    if projects:
        projectStr = "'%s'" % "','".join(projects)
        sql = "SELECT distinct deploymentName, projectId from machinedata where project in (%s);" % projectStr
    else:
        sql = "SELECT distinct deploymentName, projectId from machinedata;"

    logger.debug(sql)
    print(sql)

    conn = createConnection(database)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    logger.debug(sql)
    cur.execute(sql)

    allDBDeploymentData = cur.fetchall()

    conn.close()

    for thisDeployment in allDBDeploymentData:
        if allDeploymentData.get(thisDeployment['projectId'], None):
            allDeploymentData[thisDeployment['projectId']].append(thisDeployment['deploymentName'])
        else:
            allDeploymentData[thisDeployment['projectId']] = [thisDeployment['deploymentName']]

    return allDeploymentData

def getDeploymentDataForMetadatFile(database, projects=None):
    allDeploymentData = {}
    
    if projects:
        projectStr = "'%s'" % "','".join(projects)
        sql = "SELECT deploymentName, projectId, vra8MachineId from machinedata where project in (%s);" % projectStr
    else:
        sql = "SELECT deploymentName, projectId, vra8MachineId from machinedata;"

    logger.debug(sql)
    print(sql)

    conn = createConnection(database)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    logger.debug(sql)
    cur.execute(sql)

    allDBDeploymentData = cur.fetchall()

    conn.close()

    for thisDeployment in allDBDeploymentData:
        if allDeploymentData.get(thisDeployment['projectId'], None):
            if allDeploymentData[thisDeployment['projectId']].get(thisDeployment['deploymentName'], None):
                allDeploymentData[thisDeployment['projectId']][thisDeployment['deploymentName']].append(thisDeployment['vra8MachineId'])
            else:
                allDeploymentData[thisDeployment['projectId']][thisDeployment['deploymentName']] = [thisDeployment['vra8MachineId']]
        else:
            allDeploymentData[thisDeployment['projectId']] = {thisDeployment['deploymentName']:[thisDeployment['vra8MachineId']]}

    return allDeploymentData

def getProjectDataForMetadatFile(database, projects=None):
    allProjectData = {}
    
    if projects:
        projectStr = "'%s'" % "','".join(projects)
        sql = "SELECT distinct project, projectId from machinedata where project in (%s);" % projectStr
    else:
        sql = "SELECT distinct project, projectId from machinedata;"

    logger.debug(sql)
    print(sql)

    conn = createConnection(database)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    logger.debug(sql)
    cur.execute(sql)

    allDBProjectData = cur.fetchall()

    conn.close()

    for thisProject in allDBProjectData:
        allProjectData[thisProject['projectId']] = thisProject['project']

    return allProjectData



def updateDeploymentIcon(hostfqdn, token, deploymentId, thisIconId):
    headers = {
        'accept': "application/json",
        'content-type': "application/json",
        'Authorization': token
    }

    vraClient = RESTClient()

    reqUrl = const.vra8_update_deployment % (hostfqdn, deploymentId)
    print(reqUrl)

    payload = {
        "iconId" : thisIconId
    }

    resp = vraClient.patch(reqUrl, headers=headers, data=json.dumps(payload))

    if resp.status_code == 200:
        data = resp.json()
        logger.debug(data)
        return True

    else:
        logger.error('Unable to get integrations')
        logger.error('Response Code: %s' % resp.status_code )
        logger.error('Response: %s' % json.dumps(resp.json()) )
        print('Unable to get integrations')
        print('Response Code: %s' % resp.status_code )
        print('Response: %s' % json.dumps(resp.json()) )
        return False

            