import onboardingUtils
import logging
import sqlite3
from sqlite3 import Error
import vacfg_constants as const
import json
from requests_ntlm2 import HttpNtlmAuth
import requests
from xml.dom import minidom
from concurrent.futures import ThreadPoolExecutor, as_completed
import onboardingUtilsHistory

logger = logging.getLogger(__name__)

def create_connection(dbFileName):
    """ create a database connection to a SQLite database """
    conn = None
    try:
        conn = sqlite3.connect(dbFileName)
        return conn
    except Exception as e:
        print(e)

    return conn

def create_table(conn, create_table_sql, tableName):
    """ create a table from the create_table_sql statement
    :param conn: Connection object
    :param create_table_sql: a CREATE TABLE statement
    :return:
    """
    try:
        c = conn.cursor()
        dropQuery = 'DROP TABLE IF EXISTS %s;' % (tableName)
        c.execute(dropQuery)
        c.execute(create_table_sql)
    except Exception as e:
        print(e)

    return True

#may not be used
def update_security_group_tovm_vmId( updateData, dbFileName, conn = None  ):
    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    sql = ''' UPDATE securitygrouptovm set vra8MachineId = ? where machineId = ?;
    '''

    cur = conn.cursor()
    ret = cur.executemany(sql, updateData)
    conn.commit()

    if gotLocalConn:
        conn.close()
    
    return True

def update_security_group_tovm_groupId( updateData, dbFileName, conn = None  ):
    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    sql = ''' UPDATE securitygrouptovm set vra8SGId = ? where sgName = ?;
    '''

    #print(sql)
    logger.debug(sql)
    #print(updateData)
    logger.debug(updateData)

    cur = conn.cursor()
    ret = cur.executemany(sql, updateData)
    conn.commit()

    if gotLocalConn:
        conn.close()
    
    return True

def update_security_group_resourceId( updateData, dbFileName, conn = None  ):
    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    sql = ''' UPDATE networkresourcedata set vra8ResourceId = ? where resourceName = ?;
    '''

    #print(sql)
    #print(updateData)
    logger.debug(sql)
    logger.debug(updateData)

    cur = conn.cursor()
    ret = cur.executemany(sql, updateData)
    conn.commit()

    if gotLocalConn:
        conn.close()
    
    return True

def update_security_group_tovm_type( updateData, dbFileName, conn = None  ):
    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    sql = ''' UPDATE securitygrouptovm set sgType = ? where sgName = ?;
    '''

    cur = conn.cursor()
    ret = cur.executemany(sql, updateData)
    conn.commit()

    if gotLocalConn:
        conn.close()
    
    return True

def create_security_group_tovm_table(dbFileName):

    conn = create_connection(dbFileName)
    sql_create_security_group_table = """ CREATE TABLE IF NOT EXISTS securitygrouptovm (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sgName text NOT NULL,
        sgType text NOT NULL,
		machineId text NOT NULL,
		vra8SGId text,
        vra8MachineId text,
        sgId text NOT NULL );
        """

    if conn is not None:
        print('Creating Table securitygrouptovm')
        res = create_table(conn, sql_create_security_group_table, 'securitygrouptovm')
        conn.close()

    if res:
    	return True
    else:
    	return False

def create_network_resource_properties_table(dbFileName):
    conn = create_connection(dbFileName)
    sql_create_network_resource_properties_table = """ CREATE TABLE IF NOT EXISTS networkresourceproperties (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        resourceId text,
        propertyName text,
        newPropertyName text,
        propertyValue text
        );
        """
    if conn is not None:
        print('Creating Table networkresourceproperties')
        res = create_table(conn, sql_create_network_resource_properties_table, 'networkresourceproperties')
        conn.close()

    if res:
        return True
    else:
        return False

def create_network_resource_data_table(dbFileName):
    conn = create_connection(dbFileName)
    sql_create_network_resource_table = """ CREATE TABLE IF NOT EXISTS networkresourcedata (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        import text default 'yes',
        resourceName text,
        externalId text,
        resourceId text NOT NULL UNIQUE,
        ipAddress text,
        vra8ResourceId text,
        machineId text,
        vra8MachineId text,
        owner text,
        newOwner text,
        businessGroup text,
        project text,
        projectId text,
        endpointFQDN text,
        endpointType text,
        endpointId text,
        leaseEnd text,
        resourceType text,
        resourceSubType text,
        cloudTemplateName text,
        cloudTemplateId text,
        deploymentName text,
        deploymentId text,
        deploymentDescription text,
        deploymentDate text );
        """

    if conn is not None:
        print('Creating Table networkresourcedata')
        res = create_table(conn, sql_create_network_resource_table, 'networkresourcedata')
        conn.close()

    if res:
        return True
    else:
        return False

def insertSecurityGroupToVM(securityGroupData, dbFileName, conn = None ):

    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    sql = ''' INSERT OR IGNORE INTO securitygrouptovm(sgName,sgType,machineId,sgId)
        VALUES (?,?,?,?);
    '''
    cur = conn.cursor()
    ret = cur.executemany(sql, securityGroupData)
    conn.commit()

    if gotLocalConn:
        conn.close()
        
    return True

def getAllSecurityGroupData(dbFileName, project):
    conn = sqlite3.connect(dbFileName)

    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    logger.debug('DB filename: ' + dbFileName)

    sql = '''select securitygrouptovm.id,  machinedata.deploymentName, machinedata.projectId, machinedata.deploymentId, securitygrouptovm.sgName,
                    securitygrouptovm.sgType,  securitygrouptovm.machineId ,securitygrouptovm.vra8MachineId, securitygrouptovm.rvra8SGId
                    from securitygrouptovm INNER JOIN machinedata on machinedata.machineId = securitygrouptovm.machineId 
                    where machinedata.project = '%s'
                    order by securitygrouptovm.sgName asc;
          ''' % (project)

    logger.debug(sql)
    #print(sql)

    c.execute(sql)

    res = c.fetchall()
    logger.debug(res)
    conn.close()

    return res

def exportvRA7SecurityGroupToVMData(iaasHost, iaasUser,iaasPassword, domain, dbFileName, top=500):

    logger.info('Processing Security Groups')
    print('Processing Security Groups')
    
    allDone = False
    skip = 0
    count = 1
    gotData = False
        
    print('No, SecurityGroup Name, SecurityGroup ID')

    auth=HttpNtlmAuth('%s\\%s' % (domain, iaasUser),iaasPassword)

    while not allDone:
        localCounter = 0
        allSecurityGroupData = []
        reqUrl = "https://%s/repository/data/VCNSModelEntities.svc/VirtualMachineToSecurityGroups()?$skip=%s&$top=%s&$expand=SecurityGroup" % (iaasHost, skip, top)
        #print(reqUrl)
        logger.debug(reqUrl)

        resp = requests.get(reqUrl, verify=False, auth=auth)
        
        if resp.status_code != 200:
            print('Unable to get security group data from Iaas repo')
            print(resp.text)
            print(resp.status_code)
            return False
            
        #print(resp.status_code)

        xmldoc = minidom.parseString(resp.text)
        itemlist = xmldoc.firstChild.childNodes
        for s in itemlist:
            vmi = sgn = sgi = ''

            if s.tagName != 'entry':
                continue

            #print(dir(s))
            #print(s.toprettyxml())
            logger.debug(s.toprettyxml())

            vmId =  s.getElementsByTagName('d:VirtualMachineId')
            if len(vmId) > 0:
                if vmId[0].firstChild:
                    vmi = vmId[0].firstChild.nodeValue

            sgName = s.getElementsByTagName('d:Name')
            if len(sgName) > 0:
                if sgName[0].firstChild:
                    sgn = sgName[0].firstChild.nodeValue

            sgId = s.getElementsByTagName('d:SecurityGroupId')
            if len(sgId) > 0:
                if sgId[0].firstChild:
                    sgi = sgId[0].firstChild.nodeValue

            count = count + 1
            localCounter = localCounter + 1
            thisSGData = (sgn,
                          'EXISTING',
                          vmi,
                          sgi)
            allSecurityGroupData.append(thisSGData)
            print('%s - %s - %s' % (count, sgn, sgi))

        skip = count - 1
        if localCounter < top:
            allDone = True

        if len(allSecurityGroupData) > 0:
            gotData = True
        
        insertSecurityGroupToVM(allSecurityGroupData, dbFileName)   
    

    if not gotData: 
        print('Unable to log into IAAS host %s with username %s or NOT authorised for IAAS Repository access. NO DATA RETURNED FROM IAAS REPO' % (iaasHost, iaasUser))
        logger.error('Unable to log into IAAS host %s with username %s or NOT authorised for IAAS Repository access. NO DATA RETURNED FROM IAAS REPO' % (iaasHost, iaasUser))
        return False


    return True

def getDeltaSGData(vraHost, token, dbFileName, pagesize=200):
    
    url = "https://{0}/catalog-service/api/consumer/resources?limit={1}&%24filter=resourceType/name+eq+%27Security%20Group%27".format(vraHost, pagesize)
    headers = {"Accept": "application/json", 
               "Content-Type": "application/json",
               "Authorization": "Bearer %s" % (token)}

    while url:

        updateData = []
        #print(url)
        logger.debug(url)
        rep = requests.get(url, headers=headers, verify=False )
            
        data = rep.json()

        if 'content' in data.keys():
            print('vRA returned data for %s deployments' % len(data['content']))
        else:
            print('No Content Returned for Request')
            return False

        logger.debug(data)

        for securityGroup in data.get('content', []):
            if securityGroup['iconId'] == 'on_demand_security_group':
                updateData.append(('NEW', securityGroup["name"]))
            
        url=False
        for l in data.get("links",[]):
            if l["rel"] == "next":
                # Fix url for curl - $ breaks the url
                url = l["href"].replace("$", "%24")

        update_security_group_tovm_type(updateData, dbFileName)

    return True



def updateVMIds(dbFileName, conn=None):
    
    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    sql = ''' UPDATE securitygrouptovm
                SET vra8MachineId = (
                    SELECT machinedata.vra8MachineId
                    FROM machinedata
                    WHERE machinedata.machineId = securitygrouptovm.machineId
                )
                WHERE EXISTS (
                    SELECT 1
                    FROM machinedata 
                    WHERE machinedata.machineId = securitygrouptovm.machineId);
    '''
    cur = conn.cursor()
    ret = cur.execute(sql)
    conn.commit()

    if gotLocalConn:
        conn.close()
        
    return True

def clearVMValidationData(dbFileName, conn=None):

    gotLocalConn = False
    blankVMData = False
    blankNSXData = False

    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    sql = ''' UPDATE securitygrouptovm set vra8MachineId = NULL , vra8SGId = NULL;'''
    cur = conn.cursor()
    ret = cur.execute(sql)
    conn.commit()

    if cur.rowcount > 0:
        blankVMData =  True
    else:
        print('Blanking Security Groups Data made NO change to DB, Security Groups Table might be empty')
        logger.warning('Blanking Security Groups Data made NO change to DB, Security Groups Table might be empty')

    sql = ''' UPDATE networkresourcedata set vra8MachineId = NULL , vra8ResourceId = NULL;'''
    cur = conn.cursor()
    ret = cur.execute(sql)
    conn.commit()

    if cur.rowcount > 0:
        blankNSXData =  True
    else:
        print('Blanking Security Groups Data made NO change to DB, Security Groups Table might be empty')
        logger.warning('Blanking Security Groups Data made NO change to DB, Security Groups Table might be empty')


    sql = '''select COUNT(*) as hasData from securitygrouptovm where vra8SGId IS NOT NULL;'''
    cur = conn.cursor()
    ret = cur.execute(sql)

    notBlank = cur.fetchall()   
    
    #print(notBlank[0][0])
    if int(notBlank[0][0]) > 0:
        print('Unable to blank security group data')
        logger.error('Unable to blank security group data')
    else:
        blankVMData =  True

    sql = '''select COUNT(*) as hasData from networkresourcedata where vra8MachineId IS NOT NULL OR vra8ResourceId IS NOT NULL ;'''
    cur = conn.cursor()
    ret = cur.execute(sql)

    notBlankNSX = cur.fetchall()   
    
    #print(notBlankNSX[0][0])
    if int(notBlankNSX[0][0]) > 0:
        print('Unable to blank security group data')
        logger.error('Unable to blank security group data')
    else:
        blankNSXData =  True

    if gotLocalConn:
        conn.close()
    
    if blankVMData and blankNSXData:
        return True
    else:
        return False

def removeDeltaSGs(database, deltaVMS, conn=None):

    gotLocalConn = False

    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    deltaStr = "','".join(deltaVMS)
    sql = ''' DELETE from securitygrouptovm where machineId in (select from machinedata where machineName in ('%s'));
    ''' % deltaStr

    logger.debug('Removing Security groups for delta VMs from db')
    logger.debug(sql)
    #print(sql)

    cur = conn.cursor()
    ret = cur.execute(sql)
    conn.commit()

    if gotLocalConn:
        conn.close()
    
    return True

def sgNullCheck(dbFileName, project=None, conn=None):

    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    if project:
        sql = '''SELECT securitygrouptovm.sgName, machinedata.machineName
                FROM securitygrouptovm
                INNER JOIN machinedata ON securitygrouptovm.machineId = machinedata.machineId
                WHERE securitygrouptovm.vra8MachineId IS NULL and machinedata.project = '%s'; 
        ''' % project
    else:
        sql = '''SELECT securitygrouptovm.sgName, machinedata.machineName
                FROM securitygrouptovm
                INNER JOIN machinedata ON securitygrouptovm.machineId = machinedata.machineId
                WHERE securitygrouptovm.vra8MachineId IS NULL;
        '''

    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    logger.debug(sql)
    #print(sql)
    cur.execute(sql)

    allNullRes = cur.fetchall()     

    if gotLocalConn:
        conn.close()
        
    return allNullRes

def validateSecurityGroups(dbFileName, hostname, token, authType, project=None):
    verifySG = False
    problemSG = []

    res = updateVMIds(dbFileName)

    if not res:
        print('Unable to get machine IDs for related security groups')
        logger.error('Unable to get machine IDs for related security groups')
        return False, problemSG

    allBlanks = sgNullCheck(dbFileName, project)
    for row in allBlanks:
        problemSG.append('%s:%s' % (row['machineName'],row['sgName']))

    if len(problemSG) > 0:
        print('Unabel to get machine ids for related security groups')
        print(problemSG)
        logger.error('Unabel to get machine ids for related security groups')
        logger.error(problemSG)

    allSgData = getAllSecurityGroups(hostname, token)

    verifySG, problemSGRes = verifySecurityGroupsToVM(dbFileName, allSgData, project)
    verifySGResource, problemSGResource = verifySecurityGroupsStandalone(dbFileName, allSgData, project)
    
    problemSG.extend(problemSGRes)
    problemSG.extend(problemSGResource)

    if len(problemSG) > 0:
        verifySG = False

    return verifySG, problemSG

def verifySecurityGroupsToVM(dbFileName, allSgData, project=None, conn=None):

    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    if project:
        sql = '''Select distinct sgName
                 FROM securitygrouptovm
                 INNER JOIN machinedata ON securitygrouptovm.machineId = machinedata.machineId
                 WHERE machinedata.project = '%s'; 
        ''' % project
    else:
        sql = '''Select distinct sgName from securitygrouptovm;'''

    conn.row_factory = lambda cursor, row: row[0]
    cur = conn.cursor()

    logger.debug(sql)
    #print(sql)
    cur.execute(sql)

    allSGNames = cur.fetchall()

    if gotLocalConn:
        conn.close()

    logger.debug(allSGNames)
    logger.debug(len(allSGNames))

    problemSG = []
    updateSG = []

    for thisSG in allSGNames:
        if allSgData.get(thisSG, None):
            updateSG.append((allSgData[thisSG]['id'], thisSG))
        else:
            problemSG.append(thisSG)
            
    res = update_security_group_tovm_groupId( updateSG, dbFileName)

    if not res:
        print('Unable to update security group ids')
        logger.error('Unable to update security group ids')
        return False, problemSG

    if len(problemSG) == 0:
        return True, problemSG
    else:
        return False, problemSG

def verifySecurityGroupsStandalone(dbFileName, allSgData, project=None, conn=None):

    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    if project:
        sql = '''Select distinct resourceName
                 FROM networkresourcedata
                 WHERE project = '%s'
                 AND resourceType = 'Infrastructure.Network.SecurityGroup.NSX'; 
        ''' % project
    else:
        sql = '''Select distinct resourceName from networkresourcedata WHERE resourceType = 'Infrastructure.Network.SecurityGroup.NSX';'''

    conn.row_factory = lambda cursor, row: row[0]
    cur = conn.cursor()

    logger.debug(sql)
    #print(sql)
    cur.execute(sql)

    allSGNames = cur.fetchall()

    if gotLocalConn:
        conn.close()

    logger.debug(allSGNames)
    logger.debug(len(allSGNames))

    problemSG = []
    updateSG = []

    for thisSG in allSGNames:
        if allSgData.get(thisSG, None):
            updateSG.append((allSgData[thisSG]['id'], thisSG))
        else:
            problemSG.append(thisSG)
            
    res =  update_security_group_resourceId(updateSG, dbFileName)

    if not res:
        print('Unable to update security group ids')
        logger.error('Unable to update security group ids')
        return False, problemSG

    if len(problemSG) == 0:
        return True, problemSG
    else:
        return False, problemSG

def getAllSecurityGroups(hostname, token):

    headers = {'Authorization': '%s' % (token)}
    
    allSecurityGroupsDict = {}

    top = 200
    skip = 0
    totalElements = top * 3

    vraClient = onboardingUtils.RESTClient()
    
    while skip < totalElements:
        reqUrl = '%s?$top=%s&$skip=%s' % (const.vra8_get_all_security_groups % (hostname), top, skip)
        logger.debug('Request URL: %s' % (reqUrl))
        #print(reqUrl)
        resp = vraClient.get(reqUrl, headers=headers)
        if resp.status_code == 200:
            data = resp.json()
        
            logger.debug(data)
            for thisItem in data['content']:
                sgName = thisItem['name']    
                allSecurityGroupsDict[sgName] = thisItem

        else:
            logger.error('Unable to get security group data')
            logger.error('REST RESPONSE CODE: %s' % resp.status_code)
            logger.error(resp.text)
            print('Unable to get security group data')
            print('REST RESPONSE CODE: %s' % resp.status_code)
            print(resp.text)
            return None
        
        totalElements = data['totalElements']
        skip = skip + top

    return allSecurityGroupsDict

def getSGtoVMIdMap(dbFileName, machineData, conn=None):

    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    idList = [thisMachine['machineId'] for thisMachine in machineData.values()]
    idStr = "'%s'" % "','".join(idList)
    #print(idStr)
    sql = '''select machineId, vra8SGId  from securitygrouptovm where machineId in (%s);''' % idStr

    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    logger.debug(sql)
    print(sql)
    cur.execute(sql)

    allSGRows = cur.fetchall()
    allSGs = {}

    for thisEntry in  allSGRows:
        allSGs.setdefault(thisEntry['machineId'],[]).append(thisEntry['vra8SGId'])

    if gotLocalConn:
        conn.close()
        
    return allSGs

def extractNetworkResourceDeploymentData(vraUser, vraPassword, vraTenant, vraHost, pagesize, iaasHost, iaasUser,iaasPassword, domain, threadCount, dbFileName, getHistory=False):

    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    token = onboardingUtils.getToken(vraHost, vraUser, vraPassword, 'vra76', None, vraTenant)
    
    headers["Authorization"] = "Bearer %s" % (token)

    reqUrl = "https://{0}/catalog-service/api/consumer/resources?limit={1}&%24filter=resourceType/name+eq+'Deployment'".format(vraHost, pagesize)
    print("resourceName, deploymentName, deploymentId, owner, businessGroup, ipAddress, externalId, netResourceId, endpointId, endpointType, resourceType, resourceSubType, Deployment Date, leaseEnd, Description")

    endpointIdMap = getNSXEndpointIds(iaasHost, iaasUser,iaasPassword, domain)
    print(endpointIdMap)
    while reqUrl:
    
        resp = requests.get(reqUrl, headers=headers, verify=False )

        if resp.status_code != 200:
            print('Unable to get vra deployment data')
            exit(1)
        
        threads = []
        updateDataNSX = []
        with ThreadPoolExecutor(max_workers=threadCount) as executor:

            data = resp.json()
            for deployment in data["content"]:
                threads.append(executor.submit(processDeployment, deployment, vraHost, pagesize, headers, getHistory))
        
            for task in as_completed(threads):
                depResourceData, historyData = task.result()
                if getHistory and len(historyData) > 0:
                    onboardingUtilsHistory.insertHistory(historyData, dbFileName)
                 
                for thisResource in depResourceData:
                    updateDataNSX.append((thisResource[0],thisResource[1],thisResource[2],thisResource[3],thisResource[4],endpointIdMap.get(str(thisResource[5]),'UNKNOWN'),thisResource[6],thisResource[7],thisResource[8],thisResource[9],thisResource[10],thisResource[11],thisResource[12],thisResource[13],thisResource[14]))
        
        #print(updateDataNSX)
        insertNetworkResource(updateDataNSX, dbFileName)

        reqUrl=False
        for l in data["links"]:
            if l["rel"] == "next":
                # Fix url for curl - $ breaks the url
                reqUrl = l["href"].replace("$", "%24")

def processDeployment(deployment, vraHost, pagesize, headers, getHistory=False, includeSecurityGroups=False):
    
    deploymentId = deploymentDate = leaseEnd = machineId = ''
    thisDesc = str('').encode("ascii", "ignore")
    
    deploymentId = deployment["id"]
    requestId = deployment["requestId"]
    tmpDescription = '%s %s' % (deployment["description"], ',')
    description = tmpDescription.replace(',',' ').strip()
    deploymentDate = deployment["dateCreated"]
    leaseEnd = ""
    
    if deployment['hasLease']:
        leaseEnd = deployment['lease']['end']
        if not leaseEnd:
            leaseEnd = ''

    # Get all children of this deployment
    # might require paging forcing 200
    pagesize = 200
    url = "https://{0}/catalog-service/api/consumer/resources?limit={1}&%24filter=parentResource/id+eq+'{2}'".format(vraHost, pagesize, deploymentId)
    resp2 = requests.get(url, headers=headers, verify=False )
    if resp2.status_code != 200:
        print('Unable to get vra deployment data')
        exit(1)

    data2 = resp2.json()
    #print(data2)

    resourceNames = []

    allResources = []
    for child in data2["content"]:
        resourceName = ''
        netResourceId = ''
        resourceType = ''
        resourceSubType = ''
        ipAddress = ''
        externalId = ''
        endpointId = ''

        if child["resourceTypeRef"]["label"] == "Security Group":
            if child['iconId'] == 'on_demand_security_group':
                resourceSubType = 'NEW'
            else:
                resourceSubType = 'EXISTING'

            netResourceId = child.get("providerBinding", {}).get("bindingId", 'UNKNOWN')
            resourceName = child.get('name', 'UNKNOWN')
            resourceType = child.get('resourceTypeRef', {}).get('id', 'UNKNOWN') 

            for res in child.get("resourceData", {'entries': []}).get("entries", []):
                if res["key"] == "ExternalId":
                    externalId = res.get("value", {}).get("value", 'UNKNOWN')
                if res["key"] == "NSX_EndpointId":
                    endpointId = res.get("value", {}).get("value", '')

        if child["resourceTypeRef"]["label"] == "Load Balancer":
            if child['iconId'] == 'ondemand_loadbalancer':
                resourceSubType = 'NEW'
            else:
                resourceSubType = 'EXISTING'

            netResourceId = child.get("providerBinding", {}).get("bindingId", 'UNKNOWN')
            resourceName = child.get('name', 'UNKNOWN')
            resourceType = child.get('resourceTypeRef', {}).get('id', 'UNKNOWN') 

            for res in child.get("resourceData", {'entries': []}).get("entries", []):
                if res["key"] == "ExternalId":
                    externalId = res.get("value", {}).get("value", '')
                if res["key"] == "ip_address":
                    ipAddress = res.get("value", {}).get("value", '')
                if res["key"] == "NSX_EndpointId":
                    endpointId = res.get("value", {}).get("value", '')
            
        if resourceName:
            resourceNames.append(resourceName)
        else:
            continue

        print ("{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}, {13}, {14}".format(
                resourceName,
                deployment["name"],
                str(deploymentId),
                deployment["owners"][0]["ref"],
                deployment["organization"]["subtenantLabel"],
                ipAddress,
                externalId, 
                netResourceId, 
                endpointId, 
                'NSX',
                resourceType, 
                resourceSubType, 
                deploymentDate,
                leaseEnd,
                thisDesc.decode('utf-8')
                ))
        
        thisResource = (resourceName, netResourceId, externalId, deployment["owners"][0]["ref"],
                deployment["organization"]["subtenantLabel"],endpointId, 'NSX', ipAddress,  leaseEnd, resourceType, 
                resourceSubType, deployment["name"], str(deploymentId), thisDesc.decode('utf-8'), deploymentDate)
        
        allResources.append(thisResource)
    thisHistory = None
    #if getHistory:
    #    thisHistory = onboardingUtilsHistory.extractHistoryData(vraHost, headers, resourceNames, deploymentId)

    return allResources, thisHistory

def getNSXEndpointIds(iaasHost, iaasUser,iaasPassword, domain, top=500):

    logger.info('Processing NSX Endpoints')
    print('Processing  NSX Endpoints')
    
    allDone = False
    skip = 0
    count = 1
    gotData = False
        
    print('No, Endpoint Name, Endpoint ID, Endpoint FQDN')

    auth=HttpNtlmAuth('%s\\%s' % (domain, iaasUser),iaasPassword)

    while not allDone:
        localCounter = 0
        allEndpointData = {}
        reqUrl = "https://%s/repository/data/VCNSModelEntities.svc/VCNSEndpoints()?$skip=%s&$top=%s" % (iaasHost, skip, top)
        print(reqUrl)
        logger.debug(reqUrl)

        resp = requests.get(reqUrl, verify=False, auth=auth)
        
        if resp.status_code != 200:
            print('Unable to get NSX Endpoint data from Iaas repo')
            print(resp.text)
            print(resp.status_code)
            return False

        xmldoc = minidom.parseString(resp.text)
        itemlist = xmldoc.firstChild.childNodes
        for s in itemlist:
            epi = epn = epfqdn = ''

            if s.tagName != 'entry':
                continue

            #print(dir(s))
            #print(s.toprettyxml())
            logger.debug(s.toprettyxml())

            epId =  s.getElementsByTagName('d:Id')
            if len(epId) > 0:
                if epId[0].firstChild:
                    epi = epId[0].firstChild.nodeValue

            epFQDN = s.getElementsByTagName('d:Address')
            if len(epFQDN) > 0:
                if epFQDN[0].firstChild:
                    epfqdn = epFQDN[0].firstChild.nodeValue.replace('https://','')

            epName = s.getElementsByTagName('d:Name')
            if len(epName) > 0:
                if epName[0].firstChild:
                    epn = epName[0].firstChild.nodeValue

            count = count + 1
            localCounter = localCounter + 1
            allEndpointData[epi] = epfqdn

            
            print('%s - %s - %s' % (count, epi, epfqdn))

        skip = count - 1
        if localCounter < top:
            allDone = True

    return allEndpointData

def insertNetworkResource(insertData, dbFileName, conn = None ):

    gotLocalConn = False
    if not conn:
        conn = create_connection(dbFileName)
        gotLocalConn = True

    sql = ''' INSERT OR IGNORE INTO networkresourcedata(resourceName, resourceId, externalId, owner, businessGroup, endpointFQDN, endpointType, ipAddress, leaseEnd, resourceType, resourceSubType, deploymentName, deploymentId, deploymentDescription, deploymentDate)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);
    '''

    cur = conn.cursor()
    ret = cur.executemany(sql, insertData)
    conn.commit()
    
    if gotLocalConn:
        conn.close()
        
    return True
