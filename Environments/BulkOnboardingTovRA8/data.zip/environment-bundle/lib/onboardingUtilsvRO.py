import onboardingUtils
import logging
from xml.dom import minidom
import csv
import json
import os

logger = logging.getLogger(__name__)

def getvROResourceFolderID(baseurl, token, resourceFolderName):

    headers = {
        'accept': "application/xml",
        'Authorization': "Bearer %s" % token
        }

    vraClient = onboardingUtils.RESTClient()
    reqUrl = '%s/api/categories' % (baseurl)
    logger.debug('Request URL: %s' % (reqUrl))

    response = vraClient.get(reqUrl, headers=headers)
    print('URL: %s' % reqUrl)
    print('Response Code: %s' % response.status_code)
    logger.debug('Response Code: %s' % response.status_code)
    
    xmldoc = minidom.parseString(response.text)
    itemlist = xmldoc.firstChild.childNodes
    resource_folder_id = None
    for s in itemlist:
        for x in s.childNodes:
            thisObj = {}
            foundResource = False
            for p in x.childNodes:
                thisName = p.getAttribute('name')
                if thisName:
                    thisObj[thisName] = p.getAttribute('value')
                if 'ResourceElementCategory' == p.getAttribute('value'):
                    foundResource = True

            if foundResource:
                if thisObj['name'] == resourceFolderName:
                    resource_folder_id = thisObj['id']
                    break
        if resource_folder_id:
            break

    if not resource_folder_id:
        print('Unable to get ID for Resource Element Folder')
        logger.error('Unable to get ID for Resource Element Folder')
        return None

    else:
        print('Found Resource Element Folder ID: %s' % (resource_folder_id))
        logger.debug('Found Resource Element Folder ID: %s' % (resource_folder_id))

    return resource_folder_id

def getvROResourceElementID(baseurl, token, resourceElementName):

    headers = {
        'accept': "application/json",
        'Authorization': "Bearer %s" % token
        }

    vraClient = onboardingUtils.RESTClient()
    reqUrl = '%s/api/resources' % (baseurl)
    logger.debug('Request URL: %s' % (reqUrl))
    logger.debug(resourceElementName)

    allElementsFound = []

    response = vraClient.get(reqUrl, headers=headers)
    print('URL: %s' % reqUrl)
    print('Response Code: %s' % response.status_code)
    logger.debug('Response Code: %s' % response.status_code)
    
    print (response.json())
    logger.debug(response.json())
    if response.status_code == 200:
        data = response.json()
        for thisElement in data['link']:
            thisObj = {}
            for thisAttribute in thisElement['attributes']:
                if thisAttribute['name'] == 'name':
                    thisObj['name'] = thisAttribute.get('value', None)
                elif thisAttribute['name'] == 'id':
                    thisObj['id'] = thisAttribute.get('value', None)
            
            if thisObj.get('name', None):
                if thisObj['name'] == resourceElementName:
                    allElementsFound.append(thisObj)

        if len(allElementsFound) == 1:
            return allElementsFound[0]['id']
        elif len(allElementsFound) == 0:
            print ('Unable to find any element with name %s' % (resourceElementName))
            logger.warning('Unable to find any element with name %s' % (resourceElementName))
            return None
        else:
            print ('Multiple elements with name %s found, please remove duplicate elements from vRO' % (resourceElementName))
            logger.warning('Multiple elements with name %s found, please remove duplicate elements from vRO' % (resourceElementName))
            return None

    else:
        print('Unable to get resource element objects')
        logger.debug('Unable to get resource element objects')

    return None

def updatevROResourceElementType(baseurl, token, resourceElementName, fileType="text/plain", actionId = "fee5ad53-bf4d-4a4a-890b-748a28c0beac"):

    headers = {
        'accept': "application/json",
        'Authorization': "Bearer %s" % token
        }

    vraClient = onboardingUtils.RESTClient()
    reqUrl = '%s/api/actions/%s/executions' % (baseurl, actionId)

    logger.debug('Request URL: %s' % (reqUrl))

    payload = {"parameters":
                    [
                        {
                            "value": {"string":{ "value": resourceElementName}},
                            "type": "string",
                            "name": "resourceElementName",
                            "scope": "local"
                        },
                        {
                            "value":{"string":{"value": fileType}},
                            "type": "string",
                            "name": "fileType",
                            "scope": "local"
                        }
                    ]
                }
    

    resp = vraClient.post(reqUrl, headers=headers, data=json.dumps(payload))

    if resp.status_code == 200:
        logger.debug('Submitted file type change request successfully')
        return True
    else:
        logger.error('Submitted file type change request')
        logger.error('REST RESPONSE CODE: %s' % resp.status_code)
        logger.error(resp.text)
        logger.error(json.dumps(payload))
        print(json.dumps(payload))
        print('Unable to create bulk deployment')
        print('REST RESPONSE CODE: %s' % resp.status_code)
        print(resp.text)
        return False

def saveDataResourceElementvRO(baseurl, token, filePath, resourceFolderName, fileType="text/plain"):

    resource_folder_id = getvROResourceFolderID(baseurl, token, resourceFolderName)

    if not resource_folder_id:
        print('Unable to get ID for Resource Element Folder')
        logger.error('Unable to get ID for Resource Element Folder') 
        print('Unable to save content to vRO')
        exit(1)

    reqUrl = '%s/api/resources?categoryId=%s' % (baseurl, resource_folder_id)
    vraClient = onboardingUtils.RESTClient()
    headers = {
        'accept': "application/json",
        'Authorization': "Bearer %s" % token
        }
    
    MAX_SIZE = 15 * 1024 * 1024 # 15 MB
    
    with open(filePath, 'rb') as f:
    
        file_size = os.path.getsize(filePath)
        uploadList = []
    
        if file_size > MAX_SIZE:
            num_parts = file_size // MAX_SIZE + 1
        
            contents = f.read()
        
            # Split the contents into parts
            parts = [contents[i:i+MAX_SIZE] for i in range(0, len(contents), MAX_SIZE)]
        
            # Write each part to a new file
            for i, part in enumerate(parts):
                with open(filePath.replace('.log','_part%s.log' % i), "wb") as part_file:
                    part_file.write(part)
                    uploadList.append(filePath.replace('.log','_part%s.log' % i))
        else:
            uploadList.append(filePath)

        for thisFile in uploadList:
            with open(thisFile, 'rb') as file:
                fileInfo = {
                    "file": file,
                    "mimeType": fileType
                }
        
                response = vraClient.uploadFile(reqUrl, files=fileInfo, headers=headers)

                print('URL: %s' % reqUrl)
                print('Response Code: %s' % response.status_code)
                logger.debug('Request URL: %s' % (reqUrl))
                logger.debug('Response Code: %s' % (response.status_code))
                logger.debug('Response: %s' % (response.text) )

                print('Resource Element %s Saved to Folder %s' % (thisFile, resourceFolderName))
                logger.debug('Resource Element %s Saved to Folder %s' % (thisFile, resourceFolderName))

    return True

def vROSaveDatabase(ipaddress, username, password, sourcePath, destPath, port=22, scpTimeout=10):
    import paramiko
    from paramiko import SSHClient
    from scp import SCPClient

    ssh = SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.load_system_host_keys()
    ssh.connect(hostname=ipaddress, 
        port = port,
        username=username,
        password=password)

    scp = SCPClient(ssh.get_transport(), socket_timeout=scpTimeout)
    print('Saving metadata file to %s' % (destPath))
    scp.put(sourcePath, destPath)
    print('File saved successfully')
    scp.close()
    return True

def vROGetDatabase(ipaddress, username, password, sourcePath, destPath, port=22, scpTimeout=10):
    import paramiko
    from paramiko import SSHClient
    from scp import SCPClient

    ssh = SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.load_system_host_keys()
    ssh.connect(hostname=ipaddress, 
        port = port,
        username=username,
        password=password)

    scp = SCPClient(ssh.get_transport(), socket_timeout=scpTimeout)
    print('Saving metadata file to %s' % (destPath))
    scp.get(sourcePath, destPath)
    print('File saved successfully')
    scp.close()
    return True

def outputData(fileName, dbConnection, includeSecurityGroups=False):
    print("Exporting data into CSV............")
    cursor = dbConnection.cursor()
    cursor.execute("select import,id,machineName,machineId,owner,newOwner,businessGroup,project,datastore,networkName,endpointFQDN,endpointType,cloudTemplateName,deploymentName,deploymentId,deploymentDate, REPLACE(REPLACE(deploymentDescription, CHAR(13), ' '), CHAR(10), ' ') as deploymentDescription from machineData order by deploymentDate")
    with open(fileName, "w") as csv_file:
        csv_writer = csv.writer(csv_file, delimiter=",")
        csv_writer.writerow([i[0] for i in cursor.description])
        csv_writer.writerows(cursor)
    
    if includeSecurityGroups:
        cursor.execute("select import,id,resourceName as machineName,resourceId as machineId,owner,newOwner,businessGroup,project,null as datastore,null as networkName,endpointFQDN,endpointType,cloudTemplateName,deploymentName,deploymentId,deploymentDate, REPLACE(REPLACE(deploymentDescription, CHAR(13), ' '), CHAR(10), ' ') as deploymentDescription from networkresourcedata order by deploymentDate")
        with open(fileName, "a") as csv_file:
            csv_writer = csv.writer(csv_file, delimiter=",")
            csv_writer.writerows(cursor)

    print("Data exported Successfully")

    print("Exporting custom properties into CSV............")

    cursor.execute("select distinct propertyName, null as newPropertyName from machineproperties order by propertyName;")

    propFileName = fileName.replace('.', '_custom_properties.')
    with open(propFileName, "w") as csv_file:
        csv_writer = csv.writer(csv_file, delimiter=",")
        csv_writer.writerow([i[0] for i in cursor.description])
        csv_writer.writerows(cursor)

    print("Property Names exported Successfully")

    return True

