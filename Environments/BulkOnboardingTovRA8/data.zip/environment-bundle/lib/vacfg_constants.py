# constant vars for application

vro8_import_package = "https://%s/vco/api/packages"
vra8_refresh_token_url = 'csp/gateway/am/api/login?access_token'
vra8_access_token_url = 'iaas/api/login'
vra8_csp_token_url = 'csp/gateway/am/api/auth/api-tokens/authorize'

vra76_identity_url = 'identity/api/tokens'

catalog_item_names = ['CentOS 7.0 x64',
                      'Prelude VA OneCloud',
                      'vCenter65c with ESXi65',
                      'vIDM VA Configured',
                      'vRA 7.2-7.6']

vra76_get_bp_id = "https://%s/catalog-service/api/consumer/entitledCatalogItems?$filter=name+eq+'%s'"
vra76_get_bp_template = 'https://%s/catalog-service/api/consumer/entitledCatalogItems/%s/requests/template' 
vra76_request_deployment = 'https://%s/catalog-service/api/consumer/entitledCatalogItems/%s/requests'
vra76_get_deployment_details = 'https://%s/catalog-service/api/consumer/requests/%s/resourceViews'
#vra76_get_all_deployments = "https://%s/catalog-service/api/consumer/resources?$filter=resourceType/name+eq+'Deployment'+and+owners/ref+eq+'{1}'&limit={2}"
vra76_get_all_deployments = "https://%s/catalog-service/api/consumer/resources?$filter=resourceType/name+eq+'Deployment'&limit=50"
#vra76_get_deployment = "https://%s/catalog-service/api/consumer/resources/%s"
vra76_get_deployment = "https://%s/catalog-service/api/consumer/requests/%s/resources"
vra76_get_all_requests = 'https://%s/catalog-service/api/consumer/requests'
vra76_get_request_status = 'https://%s/catalog-service/api/consumer/requests/%s'
vra_build_no = {'8.0.1HF1':'15464201', '8.1':'15986821','8.2':'16325479' }
vidm_build_no = {'3.3.2.0':'15951611', '3.3.1.0':'14635482', '3.3.3.0':'10084102'}
vra8_license = 'FM6J2-8L2DQ-48V1J-053AP-CE246' #vac.vrealizeSuite2019Enterprise.credit
vm_resource_type_label = 'Virtual Machine'
vra8_health_url = "http://%s:8008/health"
vra8_landing_url = "https://%s"
tf_template_folder = "templates"
tf_folder = "terraform"

vra76_upd_desc = "https://%s/catalog-service/api/consumer/deployments/%s"
cava_hostname = "us08-1-vralb.oc.vmware.com"
vra76_resources = "https://%s/catalog-service/api/consumer/resources/%s"
vra8_get_datastores = "https://%s/iaas/api/fabric-vsphere-datastores"
vra8_get_regions = "https://%s/iaas/api/regions"
sp_defaults = {
  "supportsEncryption": 'false',
  "description": "CSE Auto Deploy",
  "tags": [ { "key" : "env", "value": "vsphere" } ],
  "provisioningType": "thin",
  "limitIops": "",
  "defaultItem": 'true'
}
vra8_create_sp = "https://%s/iaas/api/storage-profiles-vsphere"
vra8_get_projects = "https://%s/iaas/api/projects"
vra8_update_project_ui = "https://%s/project-service/api/projects/%s"
vra8_update_project = "https://%s/iaas/api/projects/%s"
vra8_get_fabric_computes = "https://%s/iaas/api/fabric-computes"
vra8_get_fabric_networks = "https://%s/iaas/api/fabric-networks-vsphere"
vra8_update_fabric_computes = "https://%s/iaas/api/fabric-computes/%s"
vra8_update_fabric_networks = "https://%s/iaas/api/fabric-networks-vsphere/%s"
vra8_create_policy = "https://%s/policy/api/policies"
vra8_create_net_profile = "https://%s/iaas/api/network-profiles"
vra8_get_net_profiles = vra8_create_net_profile
vra8_get_net_profile = "https://%s/iaas/api/network-profilesi/%s"
vra8_update_net_profile = vra8_get_net_profile
vra8_get_cloud_accounts_vsphere = 'https://%s/iaas/api/cloud-accounts-vsphere'
vra8_create_cloud_account_vsphere = vra8_get_cloud_accounts_vsphere
vra8_get_zones = 'https://%s/iaas/api/zones'
vra8_get_zone = 'https://%s/iaas/api/zones/%s'
vra8_update_zone = vra8_get_zone
vra8_get_image_profiles = 'https://%s/iaas/api/image-profiles'
vra8_create_image_profile = vra8_get_image_profiles
vra8_get_image_profile = 'https://%s/iaas/api/image-profiles/%s'
vra8_update_image_profile = vra8_get_image_profile
vra8_get_images = 'https://%s/iaas/api/images'
vra8_get_fabric_images = 'https://%s/iaas/api/fabric-images'
vra8_get_flavor_profiles = 'https://%s/iaas/api/flavor-profiles'
vra8_create_flavor_profile = vra8_get_flavor_profiles
vra8_update_flavor_profile = 'https://%s/iaas/api/flavor-profiles/%s'
vra8_get_flavor_profile = vra8_update_flavor_profile
vra8_get_all_projects = 'https://%s/project-service/api/projects'
vra8_get_loggedin_org = 'https://%s/csp/gateway/am/api/loggedin/user/orgs'
vra8_user_search = 'https://%s/csp/gateway/am/api/users/%s/orgs/%s/info'
vra8_group_search = 'https://%s/csp/gateway/am/api/groups/search?searchTerm=%s'
vra8_get_all_cloud_accounts = 'https://%s/iaas/api/cloud-accounts'
vra8_get_all_unmanaged_machines_for_cloud_account = "https://%s/iaas/api/machines?$filter=cloudAccountIds.item+eq+'%s'+and+projectId+ne+'*'&$select=id,name,externalId,customProperties"
vra8_get_all_discovered_machines_for_cloud_account = "https://%s/deployment/api/resources"
vra8_get_all_vsphere_cloud_accounts = 'https://%siaas/api/cloud-accounts-vsphere'
vracloud_get_users_groups = 'https://%s/csp/gateway/am/api/users/%s/orgs/%s/groups'
vracloud_group_search = 'https://%s/csp/gateway/am/api/orgs/%s/groups-search?groupSearchTerm=%s'#&pageStart=%s&pageLimit=%s'
vra8_add_blueprint_ref = 'https://%s/relocation/onboarding/blueprint'
vra8_version = 'https://%s/config.json'
vra8_get_all_cloudTemplates = 'https://%s/blueprint/api/blueprints?$select=requestScopeOrg&$select=id&$select=name&$select=projectId&$select=projectName&$skip=%s&$top=%s'
vra8_get_cloud_template = 'https://%s/blueprint/api/blueprints/%s'
vra8_get_deployment_by_name = 'https://%s/deployment/api/deployments'
vra8_update_deployment = 'https://%s/deployment/api/deployments/%s'
vra8_get_deployment_actions  = 'https://%s/deployment/api/deployments/%s/actions'
vra8_search_catalog_item_by_name = 'https://%s/catalog/api/items?search=%s'
vra8_get_catalog_item_by_id = 'https://%s/catalog/api/items/%s'
vra8_run_day2_action = 'https://%s/deployment/api/deployments/%s/requests'
vra8_get_request_status = 'https://%s/deployment/api/requests/%s'
vra8_check_user_roles = 'https://%s/csp/gateway/am/api/v2/users/%s/orgs/%s/roles'
vra8_get_deployments = 'https://%s/deployment/api/deployments'
vra8_get_deployment = 'https://%s/deployment/api/deployments/%s'
vra8_get_machine_by_id  = 'https://%s/deployment/api/deployments/%s/resources/%s'
vra8_create_network_description = 'https://%s/provisioning/resources/compute-network-descriptions'
vra8_create_network = 'https://%s//provisioning/resources/compute-networks'
vra8_create_onboarding_plan = 'https://%s/relocation/onboarding/plan'
vra8_create_onboarding_deployment = 'https://%s/relocation/onboarding/deployment'
vra8_get_all_security_groups = 'https://%s/iaas/api/security-groups'
vra8_create_resource_actions = 'https://%s/form-service/api/custom/resource-actions'
vra8_get_all_integrations = 'https://%s/iaas/api/integrations?$top=100&$skip=0&apiVersion=2021-07-15'
vra8_cust_resource_payload = {"name":"bou-powercycle",
               "description":"Bulk Onboarding Utility Temporary Resource Action, can be deleted once onboarding is completed. ",
               "displayName":"Power Cycle",
               "status":"RELEASED",
               "providerName":"vro-workflow",
               "resourceType":"Deployment",
               "runnableItem":{"id":"df3dd813-31f4-4712-ba44-8a0ca6019d12",
                               "name":"HistoryPlayer",
                               "type":"vro.workflow",
                               "endpointLink":"/resources/endpoints/c2947f49-fddb-4948-85f8-f1ab260bffbf",
                               "inputParameters":[{"value":None,"name":"State","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"Description","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"Reason","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"Requestor","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"Project","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"DateRequested","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"DateApproved","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"CompletionDetails","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"Resource","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"Action","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input01","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input02","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input03","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input04","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input05","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input06","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input07","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input08","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input09","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input10","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input11","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input12","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input13","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input14","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input15","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input16","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input17","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input18","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input19","type":"string","description":None,"scope":None},
                                                  {"value":None,"name":"input20","type":"string","description":None,"scope":None}],
                                "outputParameters":[{"value":None,"name":"Result","type":"string","description":None,"scope":None}]},
                "criteria":None}
